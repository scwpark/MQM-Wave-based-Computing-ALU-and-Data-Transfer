#ifndef  _SQL_LEX_H_
#define  _SQL_LEX_H_

#include "array_extern.h"


/////////////////////////////////////////////////////////////////////////
// 
class CATR
{
};

/////////////////////////////////////////////////////////////////////////
// 2�� �м�
typedef enum {
	
	NONE = 0,
	// data type
	DIGIT,
	HEXA,		// 16����
	STRING,		// ���ڿ� string�� ���Ѵ�.
	S_QUOTE,	// Single quotes '
	COMMA,		// ','                        5
	SEMICOLON,	// ';'

	// table 
	TABLE_NAME,  // table name
	ATTRIBUTE_NAME, // attribute name

	// aggregation
	SUM,
	AVG,		//								10
	COUNT,		
	MIN_AG,
	MAX_AG,

	// QUERY
	INSERT,
	DELETE,		//								15
	SELECT,
	UPDATE,
	FROM,
	WHERE,
	L_PAREN, // Left Parenthesis '('	//								20
	R_PAREN,

	// ���� ��.
	AND,
	OR,
	NOT,

	PLUS,		//  +
	MINUS,		//  -
	MULTIPLY,	//  *
	DIVIDE,		//  /

	NE,			//  <> or !=
	EQ,			//  =
	GT,			//  >   (�ʰ�)
	LT,			//  <   less than(�̸�), under
	EGT	,		//  >=  �̻� equal and greater than 
	ELT	,		//  <=  �̸� equal and less than

	EXIST,		//  EXIST
	NOT_EXIST,	//  NOT EXIST

	UNION,		//  U
	INTERSECT,	// 


	EXCEPT,
	LIKE,
	NOT_LIKE,
	IN,
	NOT_IN,
	
	HAVING,

	ORDER_BY,	//  sorting
	GROUP_BY,	//  group by


} Token_Type;



#define		MAX_ATTRIBUTE_NAME_LEN		50
typedef		struct
{
	// int	 size;							// byte size	
	char		name[MAX_ATTRIBUTE_NAME_LEN];	// Token Name : ex) name[size]
	Token_Type  type;			// DIGIT(10����), HEXA(16����), (STRING)���ڿ� 
} Token_Attr, STR_Type;




//////////////////////////////////////////////////////////////////////////
// Query_Report.cpp
#define  MAX_KEYWORD		100
extern   STR_Type			m_all_keyword[MAX_KEYWORD];
extern   CArrayEx			m_all_keyword_array;



#define  MAX_AGGREATION     5
extern   STR_Type			m_aggregate_keyword[MAX_AGGREATION];
extern   CArrayEx			m_aggregate_array;


//////////////////////////////////////////////////////////////////////////

#define  MAX_RELATION     9
extern  STR_Type m_relative_keyword[MAX_RELATION];
extern  CArrayEx m_relative_array;

//////////////////////////////////////////////////////////////////////////

#define  MAX_CONJUNCTION    2
extern  STR_Type m_conjunction_keyword[MAX_CONJUNCTION];
extern  CArrayEx m_conjunction_array;


#define  MAX_IN    2
extern STR_Type		m_in_keyword[MAX_IN];
extern CArrayEx		m_in_array;
//////////////////////////////////////////////////////////////////////////
// sql_lex.cpp
void		Init_Keyword(CArrayEx *m_array, STR_Type *m_keyword , int keyword_count);

Token_Type  Compare_Keyword( CArrayEx *m_array,  char * needle );
void		Not_Lexical( CArrayEx *m_token, CArrayEx *m_keyword );
void		SQL_Lex( CArrayEx *m_token, CArrayEx *m_keyword );


#define		MAX_PATTERN			50
typedef struct 
{
	int count;
	Token_Attr pattern[MAX_PATTERN];
} Pattern_Type;  // parser�� ���� Ư�� ��ڿ� �� ��ڸ� ���ϱ����� ����.

extern	 Pattern_Type		m_all_Pattern_keyword;

//////////////////////////////////////////////////////////////////////////


#endif