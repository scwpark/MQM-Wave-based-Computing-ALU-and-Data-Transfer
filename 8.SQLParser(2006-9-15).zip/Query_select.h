#ifndef  _QUERY_SELECT_H_
#define  _QUERY_SELECT_H_  
#include "sql_report.h"

int Select_Main_Parser( CArrayEx *lex_token_array, int *array_x,
					   CArrayEx *all_keyword, CArrayEx *aggregate_keyword,
					   Pattern_Type *end_pattern,
					   CATR *m_CATR , int atr_count , 
					   QUERY_Report *m_query_report);

int Select_Main_Parser( CArrayEx *lex_token_array, int *array_x,
					   CArrayEx *all_keyword, CArrayEx *aggregate_keyword,
					   CATR *m_CATR , int atr_count , 
					   QUERY_Report *m_query_report);
void select_main(CArrayEx * lex_token_array);
#endif