#ifndef _QUICKSORT_H_
#define _QUICKSORT_H_

#include "data_type.h"





// GNU Quick Sort
void quicksort (void *const pbase, size_t total_elems, size_t size,
		   COMPARE cmp);


// test source
int test_string (void);

#endif