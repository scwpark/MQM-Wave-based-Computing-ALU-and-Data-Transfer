// ArrayEx.cpp: implementation of the CArrayEx class.
//
//////////////////////////////////////////////////////////////////////
// #include "stdafx.h"
#include <string.h>
#include "ArrayEx.h"
#include "binarysearch.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CArrayEx::CArrayEx()
{

}

CArrayEx::~CArrayEx()
{

}


/*-----------------------------------------
1. ��� : add datum, sorting

2. parameter 

3. return 
1) �����ϸ� : SUCCESS
2) �����ϸ� : FAIL
-------------------------------------------*/
int CArrayEx::InsertEx(void *m_tuple)
{
	int res, loop;

	//�ڷᰡ ����� ������ 
	if( m_bm.gathered_data == SCATTER)
		Sort();
		

	// ���Ե� ��ġ ��ġ
	// 1) ó�� ���ԵǴ� ���
	if( !GetUsingResource(&m_bm) )
		return InsertAt(0, m_tuple );
	
	// 2) ���� ���ԵǴ� ���
	res = compare( GetData(GetUsingResource(&m_bm)-1), m_tuple);
	if(res < 0 )
		return InsertAt(GetUsingResource(&m_bm), m_tuple);

	// 3) �׿� 
	for( loop = 0; loop < GetUsingResource(&m_bm) ; loop++)
	{
		res = compare( GetData(loop), m_tuple);
		if( res < 0)
			;
		else
			return InsertAt(loop, m_tuple);
	}
	
	// ����Ÿ ����
	return InsertAt(loop, m_tuple);

}

/*-----------------------------------------
1. ��� : del datum, sorting

2. parameter 

3. return 
1) �����ϸ� : SUCCESS
2) �����ϸ� : FAIL
-------------------------------------------*/
int CArrayEx::DeleteEX(void *findkey, void *rem_data)
{
	int res;
	
	//�ڷᰡ ����� ������ 
	if( m_bm.gathered_data == SCATTER)
		Sort();

	res = BinarySearch( GetData(0), GetUsingResource(&m_bm), tuple_size, findkey, compare );

	if( res >=0 )
	{
		res = RemoveAt( res, rem_data);
		Compact();
	}
	else
		return FAIL;

	return res;
}
/*-----------------------------------------
1. ��� : 

2. parameter 
  
3. return 
1) �����ϸ� : zero-based  index number
2) �����ϸ� : -1
-------------------------------------------*/
int CArrayEx::FindEx(void *needle, void *find_data)
{
	int res;
	
	//�ڷᰡ ����� ������ 
	if( m_bm.gathered_data == SCATTER)
		Sort();
	
	res = BinarySearch( GetData(0), GetUsingResource(&m_bm), tuple_size, needle, compare );
	
	// �߰ߵ� ��尡 �ִٸ� 
	if( res >=0 )
	{
		memcpy(find_data, ElementAt(res), tuple_size );
	}
	
	return res;
}

int CArrayEx::FindEx(void *needle)
{
	int res;
	
	//�ڷᰡ ����� ������ 
	if( m_bm.gathered_data == SCATTER)
		Sort();
	
	res = BinarySearch( GetData(0), GetUsingResource(&m_bm), tuple_size, needle, compare );
	
	return res;
}

int CArrayEx::CompareEx(void *f, void *s)
{
	return compare(f, s);
}

int CArrayEx::IsFull()
{

	if ( GetAvailableResource( &m_bm ) == 0 )
		return TRUE;
	return FALSE;
}

int CArrayEx::IsEmpty()
{
	if ( GetUsingResource(&m_bm) == 0)
		return TRUE;
	return FALSE;
}

// ok
/*-----------------------------------------
1. ��� : remove data, and does execute LEFT COMPACT.
2. parameter 

3. return 
1) �����ϸ� : SUCCESS
2) �����ϸ� : FAIL
-------------------------------------------*/
int CArrayEx::RemoveAtEx(int nIndex, void *rem_data)
{
	Res_status_type  status;
	if( nIndex < 0 || nIndex >= m_bm.max_resource)
		return FAIL;
	
	GetStatus(&m_bm, nIndex, &status);
	if( status == NOT_USING )
		return FAIL;
	
	// �ڷ� ī��
	if( rem_data)
		memcpy(rem_data, m_data + tuple_size*nIndex, tuple_size );
	
	// nIndex�� free�������� ����.
	PutResource(&m_bm, nIndex);
	
#if 1 // data Zero 
	memset(m_data + tuple_size*nIndex, 0x0, tuple_size );
#endif
	
	// �ڷᰡ ����������� �Ǵ�.
	Compact();
	
	return SUCCESS;
}


int CArrayEx::RemoveHeadEx(void *rem_data)
{
	return RemoveAtEx(0, rem_data);

}

int CArrayEx::RemoveTailEx(void *rem_data)
{
	int res= RemoveTail(rem_data);
	Compact();
	return res;
}

int CArrayEx::operator =(CArrayEx &src)
{

	if( this->Init(src.GetMaxRes(), src.GetTupleSize()) == FALSE)
		return FALSE;
	this->SetSortFunction( src.GetSortFunction());

	// copy bm
	Copy_BM_src(this->GetBMPtr(), src.GetBMPtr());

	// copy data
	memcpy(this->GetData(0), src.GetData(0), src.GetTupleSize() * src.GetMaxRes() );

	return TRUE;
}





