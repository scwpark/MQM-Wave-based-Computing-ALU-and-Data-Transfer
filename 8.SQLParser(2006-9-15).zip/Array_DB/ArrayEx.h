// ArrayEx.h: interface for the CArrayEx class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_ARRAYEX_H_)
#define _ARRAYEX_H_


#include "ArrayData.h"

class CArrayEx : public CArrayData  
{
public:
	int RemoveTailEx(void *rem_data=NULL);
	int RemoveHeadEx( void *rem_data=NULL);
	int operator =(CArrayEx &src);
	int RemoveAtEx(int nIndex, void *rem_data = NULL);
	int IsEmpty();
	int IsFull();
	int CompareEx(void *f, void *s);
	int FindEx(void *needle);
	int FindEx(void *needle, void *find_data);
	int DeleteEX(void *findkey,  void *rem_data);
	int InsertEx(void *m_tuple);
	CArrayEx();
	virtual ~CArrayEx();

};

#endif 
