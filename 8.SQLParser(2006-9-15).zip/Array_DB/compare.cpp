// #include "stdafx.h"

#include "compare.h"
#include "data_type.h"
#include <string.h>


// ���� ���� ��Ʈ 
int IntCompareASC(const void * elem1, const void * elem2 )
{
	if( *(int *)elem1 > *(int *)elem2 )
		return 1;
	if( *(int *)elem1 == *(int *)elem2 )
		return 0;
	return -1;
}

// ���� ���� ��Ʈ 
int IntCompareDSC(const void * elem1, const void * elem2 )
{
	if( *(int *)elem1 > *(int *)elem2 )
		return -1;
	if( *(int *)elem1 == *(int *)elem2 )
		return 0;
	return 1;
}

int UIntCompare(const void * elem1, const void * elem2 )
{
	if( *(UINT *)elem1 > *(UINT *)elem2 )
		return 1;
	if( *(UINT *)elem1 == *(UINT *)elem2 )
		return 0;
	return -1;
	
}

int ShortCompare(const void * elem1, const void * elem2 )
{
	if( *(short *)elem1 > *(short *)elem2 )
		return 1;
	if( *(short *)elem1 == *(short *)elem2 )
		return 0;
	return -1;
	
}


int UShortCompare(const void * elem1, const void * elem2 )
{
	if( *(USHORT *)elem1 > *(USHORT *)elem2 )
		return 1;
	if( *(USHORT *)elem1 == *(USHORT *)elem2 )
		return 0;
	return -1;
	
}



int CharCompare(const void * elem1, const void * elem2 )
{
	if( *(char *)elem1 > *(char *)elem2 )
		return 1;
	if( *(char *)elem1 == *(char *)elem2 )
		return 0;
	return -1;
	
}

int UCharCompare(const void * elem1, const void * elem2 )
{
	if( *(UCHAR *)elem1 > *(UCHAR *)elem2 )
		return 1;
	if( *(UCHAR *)elem1 == *(UCHAR *)elem2 )
		return 0;
	return -1;
	
}

int StringCompare(const void * elem1, const void * elem2 )
{
	return (strcmp((char*) elem1, (char*) elem2));
	
}
