#ifndef _MYTEMPLATES_H_
#define _MYTEMPLATES_H_

// #include <math.h>
// r = ceil( (double)x/ y);
// r = floor( (double)x/ y);
template < class T>
T Ceiling(T x, T divider)
{
	double a = (double)x/divider;
	int    b = (int)((double)x/divider);
	
	// return (int)(  a + (x%divider > 0 ? 1 : ( x % divider < 0 ? -1 : 0)  ) );
	if( a-b>0.0)
	{
		return b+1;
	}
	else if ( a-b == 0.0)
	{
		return b;
	}
	else
	{
		return b;
	}
}

template < class T>
T Flooring(T x, T divider)
{
	double a = (double)x/divider;
	int    b = (int)((double)x/divider);
	
	// return (int)(  a + (x%divider > 0 ? 1 : ( x % divider < 0 ? -1 : 0)  ) );
	if( a-b>0.0)
	{
		return b;
	}
	else if ( a-b == 0.0)
	{
		return b;
	}
	else
	{
		return b-1;
	}
}



template < class TYPE>
TYPE MIN(TYPE a, TYPE b)
{
	return (a < b ? a : b);
}

template < class TYPE>
TYPE MAX(TYPE a, TYPE b)
{
	return (a > b ? a : b);
}

#if 0
template < class TYPE>
void swap(TYPE *a,TYPE *b)
{
	TYPE temp;
	memcpy( &temp, a,sizeof(*a));
	memcpy( a ,b, sizeof(*a));
	memcpy( b, &temp, sizeof(*a));
}
#endif


template < class TYPE>
void swap(TYPE &a,TYPE &b)
{
	TYPE temp;
	memcpy( &temp, &a,sizeof(a));
	memcpy( &a ,&b, sizeof(a));
	memcpy( &b, &temp, sizeof(a));
}



#define SWAP(a, b, size)					\
do											\
{											\
	register size_t __size = (size);		\
	register char *__a = (a), *__b = (b);	\
    do										\
	{										\
		char __tmp = *__a;					\
		*__a++ = *__b;						\
		*__b++ = __tmp;						\
	} while (--__size > 0);					\
} while (0)


template < class T >
T ABS(T &a )
{
	return  a >= 0 ? a: -a;
}
#endif