// ArrayData.h: interface for the CArrayData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_ARRAYDATA_H_)
#define _ARRAYDATA_H_


#include "bitset.h"	// Added by ClassView
#include "data_type.h"	// Added by ClassView

enum COMPACT_Type { COMPACT_SEQUENCE, COMPACT_FROM_END_TO_START};

class CArrayData  
{
public:
	int GetTupleSize() const;
	//////////////////////////////////////////////
	void Sort(COMPARE cmp);
	void Sort();
	void SetSortFunction(COMPARE cmp);
	COMPARE GetSortFunction();

	//////////////////////////////////////////////
	void* GetData(int index);
	BM* GetBMPtr();

	//////////////////////////////////////////////
	int SetSize( int nNewSize);

	int GetSize( ) const;
	int GetUpperBound( ) const;
	int GetMaxRes();
	
	int GetCurrent();

	//////////////////////////////////////////////
	int FileLoad(const char *filename);
	int FileSave(const char *filename);
protected :
	void Read_Tuples(FILE * in);
	void Write_Tuples(FILE * out);
	void FileRead(FILE *in);
	void FileWrite(FILE *out);
	
	//////////////////////////////////////////////
public :
	int FindFreePos();
	int RemoveAt(int nindex, void *rem_data = NULL);
	void * ElementAt(int nIndex);
	int RemoveTail(void *rem_data = NULL);
	int RemoveHead(void *rem_data = NULL);

	int InsertTail(void *m_tuple, int nCount = 1);
	int InsertHead(void *m_tuple, int nCount =1);
	int InsertAt(int nindex,  void * m_tuple);
	int SetAt(int nindex,  void * m_tuple);
	int GetAt(int nindex, void * m_tuple);
	

	//////////////////////////////////////////////
	
	int Compact(COMPACT_Type type = COMPACT_SEQUENCE);
protected:
	int FindIndexWithStatus( Res_status_type  status, int from_no, int to_no);
	int Compact_Sequence();
	int Compact_From_End_To_Start();

	///////////////////////////////////////////////
public :
	void Close();
	int Init( int m_max_res, int ntuple_size );
	
protected:
	int AllocData(char **m_dataPtr,int m_max_res, int ntuple_size );
	void DeAllocData(char **m_dataPtr);


	//////////////////////////////////////////////
public :



	CArrayData();
	virtual ~CArrayData();

	int MoveData(char *target, char *source,int ntuplesize, int ncount = 1);

	//////////////////////////////////////////////
protected:
	//int MoveData(char *target, char *source,int ntuplesize, int ncount = 1);
	BM		m_bm; // Free Resource management
	char	*m_data;     // tuple 
	int      tuple_size;
	COMPARE  compare;
};

#endif 
