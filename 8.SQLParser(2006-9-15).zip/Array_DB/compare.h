#ifndef  _COMPARE_H_
#define  _COMPARE_H_


// ���� ���� ��Ʈ 
int IntCompareASC(const void * elem1, const void * elem2 );

// ���� ���� ��Ʈ 
int IntCompareDSC(const void * elem1, const void * elem2 );
int UIntCompare(const void * elem1, const void * elem2 );

int ShortCompare(const void * elem1, const void * elem2 );
int UShortCompare(const void * elem1, const void * elem2 );

int CharCompare(const void * elem1, const void * elem2 );
int UCharCompare(const void * elem1, const void * elem2 );

int StringCompare(const void * elem1, const void * elem2 );


#endif