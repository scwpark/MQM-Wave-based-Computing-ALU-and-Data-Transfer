// ArrayData.cpp: implementation of the CArrayData class.
//
//////////////////////////////////////////////////////////////////////
// #include "stdafx.h"

#include <string.h>
#include <malloc.h>

#include "mytemplates.h"
#include "ArrayData.h"
#include "bitset.h"
#include "quicksort.h"
#include "heapsort.h"


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CArrayData::CArrayData()
{
	memset(&m_bm, 0x0, sizeof(BM));
	m_data = NULL;
	tuple_size = 0;
}

CArrayData::~CArrayData()
{
	Close();
}



int CArrayData::AllocData(char **m_dataPtr, int m_max_res, int ntuple_size)
{
	if( (*m_dataPtr = (char*)malloc( m_max_res * ntuple_size ) ) == NULL)
		return FAIL;
	memset( *m_dataPtr, 0x0, m_max_res * ntuple_size );
	return SUCCESS;

}

void CArrayData::DeAllocData(char **m_dataPtr)
{
	if( *m_dataPtr )
		free( *m_dataPtr );
	*m_dataPtr  = NULL;
}

int CArrayData::Init(int m_max_res, int ntuple_size)
{
	// Init�� �� ���� �ִٸ� 
	if( m_data && tuple_size)
		Close();
	// 1. Bitmap
	if( Init_BM(&m_bm, m_max_res) == FAIL)
		return FALSE;

	// 2. data size
	if( AllocData(&m_data, 	m_max_res, ntuple_size) == FAIL)
	{
		Close_BM(&m_bm);
		return FALSE;
	}
	tuple_size = ntuple_size;
	compare  = NULL;
	return TRUE;

}


void CArrayData::Close()
{
	Close_BM(&m_bm);
	DeAllocData(&m_data);
	tuple_size = 0;
}
//////////////////////////////////////////////
/*-----------------------------------------
1. ��� : index �� °�� �ڷ� �����͸� ���.
2. parameter 
1) int index : zero based index number
3. return 

-------------------------------------------*/
void * CArrayData::GetData(int index)
{
	if ( index >= 0 && index < m_bm.max_resource)
		return  m_data + index * tuple_size;
	return NULL;
}

//////////////////////////////////////////////
/*-----------------------------------------
1. ��� : 
2. parameter

3. return 

4. example
-------------------------------------------*/
int CArrayData::SetSize(int nNewSize)
{
	char *m_pArray;
	int  maxcount;
	
	maxcount = m_bm.max_resource;

	if( m_bm.max_resource == 0)
		return FAIL;

	// 1. �ڷ���� ���ٸ� 
	if( nNewSize == m_bm.max_resource )
		return SUCCESS;
	
	// BM ũ�� ����.
	SetSize_BM(  &m_bm, nNewSize );

	// 2. �ڷᰡ �� Ŀ���ٸ�
	if( nNewSize > maxcount )
	{
		// allocate data size & copy data
		AllocData( &m_pArray, nNewSize, tuple_size );
		memcpy( m_pArray,  m_data, tuple_size * maxcount );
		
		swap( m_data, m_pArray );
		free(m_pArray);
	}

	// 3. �ڷᰡ �پ��ٸ�
	else if (nNewSize < maxcount )
	{
		// allocate data size & copy data
		AllocData( &m_pArray, nNewSize, tuple_size );
		memcpy( m_pArray,  m_data, tuple_size * nNewSize );
		
		swap( m_data, m_pArray );
		free(m_pArray);		
	}

	IsCompactBM(&m_bm);
	return SUCCESS;
}

/*
1. Remarks
Returns the size of the array. Since indexes are zero-based, the size is 1 greater than the largest index.
*/
int CArrayData::GetSize() const
{
	
	return m_bm.max_resource;
}

/*
1. Remarks
Returns the current upper bound of this array. Because array indexes are zero-based, 
this function returns a value 1 less than GetSize. 
The condition GetUpperBound( ) = ��1 indicates that the array contains no elements.
2. Example
See the example for CArray::GetAt.

*/
int CArrayData::GetUpperBound() const
{
	return m_bm.max_resource -1;
}

// BM.max_resoure�� ��ȯ
int CArrayData::GetMaxRes()
{
	return m_bm.max_resource;
}


// BM.cur_resource�� ��ȯ
int CArrayData::GetCurrent()
{
	return m_bm.cur_resource;
}


//////////////////////////////////////////////////////////////////

int CArrayData::FindFreePos()
{
	int resource_num;
	BRES res;
	if ( (res = GetResource(&m_bm, &resource_num))== SUCCESS )
		return resource_num;
	return FAIL;
}


// ok
/*-----------------------------------------
1. ��� : remove data, but does not execute LEFT COMPACT.
          removed sotrage exist as empty slot.

2. parameter 

3. return 
1) �����ϸ� : SUCCESS
2) �����ϸ� : FAIL
-------------------------------------------*/
int CArrayData::RemoveAt(int nindex, void *	 rem_data)
{
	Res_status_type  status;
	if( nindex < 0 || nindex >= m_bm.max_resource)
		return FAIL;

	GetStatus(&m_bm, nindex, &status);
	if( status == NOT_USING )
		return FAIL;
	
	// �ڷ� ī��
	if( rem_data)
		memcpy(rem_data, m_data + tuple_size*nindex, tuple_size );
	
	// nIndex�� free�������� ����.
	PutResource(&m_bm, nindex);
	
#if 1 // data Zero 
	memset(m_data + tuple_size*nindex, 0x0, tuple_size );
#endif
	
	// �ڷᰡ ����������� �Ǵ�.
	IsCompactBM(&m_bm);

	return SUCCESS;
}



/*----------------------------------------------------------------------------------
1. ��� : 
Returns a temporary reference to the specified element within the array. 
It is used to implement the left-side assignment operator for arrays.

2. parameter
1)nIndex
  An integer index that is greater than or equal to 0 and less than or equal to the value returned by GetUpperBound.
  
3. return 
	A reference to an array element.

4. example

----------------------------------------------------------------------------------*/
void * CArrayData::ElementAt(int nIndex)
{
	Res_status_type  status;
	if( nIndex < 0 || nIndex >= m_bm.max_resource)
		return NULL;
	
	GetStatus(&m_bm, nIndex, &status);
	if( status == NOT_USING )
		return NULL;
	return m_data + tuple_size*nIndex;
}

int CArrayData::RemoveHead(void *rem_data)
{
	Res_status_type  status;
	int nindex = 0;
	int using_res = GetUsingResource(&m_bm);
	
	// �ڷᰡ �Ѱ��� ���ų� left�� ����Ÿ�� ������ ������  
	if( using_res == 0 || m_bm.gathered_data != LEFT_COMPACT )
		return FAIL;

	// �ڷᰡ �Ѱ��� ���ԵǾ� �ִٸ� 
	if( using_res == 1)
	{
		GetStatus(&m_bm, nindex, &status);
		if( status == NOT_USING )
			return FAIL;
		
		// �ڷ� ī��
		if(rem_data)
			memcpy(rem_data, GetData(nindex) , tuple_size );
		
		// nIndex�� free�������� ����.
		PutResource(&m_bm, nindex);
		
		// data Zero 
		memset( GetData(nindex) ,  0x0, tuple_size );

	}
	// �ڷᰡ �ΰ� �̻� ���ԵǾ� �ִٸ� 
	else if ( using_res >= 2 )
	{
		GetStatus(&m_bm, nindex, &status);
		if( status == NOT_USING )
			return FAIL;
		
		// �ڷ� ī��
		if( rem_data)
			memcpy(rem_data, GetData(nindex) , tuple_size );

		// �ڷ� �̵�
		MoveData( (char*)GetData(nindex), (char*)GetData(nindex + 1) , tuple_size, using_res - 1 );

		// using_res�� free�������� ����.
		PutResource(&m_bm, using_res-1);

		// data Zero 
		memset( GetData(using_res-1) ,  0x0, tuple_size );

		
	}
	
	return SUCCESS;
}

int CArrayData::RemoveTail(void *rem_data)
{
	Res_status_type  status;
	int nindex;
	int using_res = GetUsingResource(&m_bm);
	nindex = using_res - 1;


	// �ڷᰡ �Ѱ��� ���ų� left�� ����Ÿ�� ������ ������  
	if( using_res == 0 || m_bm.gathered_data != LEFT_COMPACT )
		return FAIL;
	
	GetStatus(&m_bm, nindex, &status);
	if( status == NOT_USING )
		return FAIL;
	
	// �ڷ� ī��
	if( rem_data )
		memcpy(rem_data, GetData(nindex) , tuple_size );	

	// using_res�� free�������� ����.
	PutResource(&m_bm, nindex);
	
	// data Zero 
	memset( GetData(nindex) ,  0x0, tuple_size );

	return SUCCESS;
}

/*----------------------------------------------------------------------------------
1. ��� : 
1) nindex(zero-based)��°�� �����ϴ� ����Ÿ�� �ڷ� ������ nindex�� �� data����
2) nindex�� �����ϴ� ����Ÿ�� ���ٸ� �׳� ���� 

2. parameter

3. return 

4. example

  	ptArray.Add(CPoint(10,20));   // Element 0
	ptArray.Add(CPoint(30,40));   // Element 1 (will become element 2)
	ptArray.InsertAt(1, CPoint(50,60));   // New element 1
----------------------------------------------------------------------------------*/
int CArrayData::InsertAt(int nindex, void *m_tuple)
{
	int x;
	Res_status_type  status;

	int avail = GetAvailableResource(&m_bm);
	
	
	if( nindex < 0 || nindex >= m_bm.max_resource || avail == 0)
		return FAIL;
	

	//  NOT_USING������ ���� ���.
	GetStatus(&m_bm, nindex, &status);
	if( status == NOT_USING)
	{
		SetResource( &m_bm,nindex);
		memcpy(m_data + tuple_size*nindex, m_tuple, tuple_size );
		

		// �ڷᰡ ����������� �Ǵ�.
		IsCompactBM(&m_bm);
		
		return SUCCESS;

	}
	else
	{
		// left
		if( m_bm.gathered_data == LEFT_COMPACT  )
		{
			// Set BM
			x = GetUsingResource(&m_bm);
			SetResource( &m_bm, x);

			// �ڷ� ī��
			MoveData((char*)GetData(nindex+1)	,	(char*)GetData(nindex)	, tuple_size,  x-nindex );
			MoveData((char*)GetData(nindex)		,	(char*)m_tuple			, tuple_size );
			
		}

	}


	return SUCCESS;

	
}

// ok
int CArrayData::InsertHead(void *m_tuple, int nCount)
{
	int x, loop;
	int avail = GetAvailableResource(&m_bm);

	// 1. �ڷ� ó�� ���� ���
	if(GetUsingResource(&m_bm) == 0 && avail )
	{
		// set bm
		x = GetUsingResource(&m_bm);
		for( loop = x ; loop < x + MIN(avail, nCount); loop++)
			SetResource( &m_bm, loop);	
		
		// �ڷ� ī��
		memcpy(m_data, m_tuple, tuple_size*MIN(avail, nCount) );
		
		return SUCCESS;		

	}

	// 2. �ڷ� ������ �����ϴ� ���.
	else
	{
		
		// �����ڿ��� �ִٸ�. 
		if( avail && m_bm.gathered_data == LEFT_COMPACT  )
		{
			// set bm
			x = GetUsingResource(&m_bm);
			for( loop = x ; loop < x + MIN(avail, nCount); loop++)
				SetResource( &m_bm, loop);
			
			// �ڷ� ī��
			// memcpy(m_data + tuple_size * x, m_tuple, tuple_size*nCount );
			MoveData( m_data + tuple_size*MIN(avail, nCount) ,  m_data , tuple_size, x );
			memcpy(m_data, m_tuple, tuple_size *MIN(avail, nCount));
		}
		else
			return FAIL;		

	}

	return SUCCESS;
}


// ok
int CArrayData::InsertTail(void *m_tuple, int nCount)
{
	int x, loop;
	int avail = GetAvailableResource(&m_bm);

	// 1. �ڷ� ó�� ���� ���
	if(GetUsingResource(&m_bm) == 0 && avail )
	{
		// set bm
		x = GetUsingResource(&m_bm);
		for( loop = x ; loop < x + MIN(avail, nCount); loop++)
			SetResource( &m_bm, loop);	
		
		// �ڷ� ī��
		memcpy(m_data, m_tuple, tuple_size*MIN(avail, nCount) );
		
		return SUCCESS;	
	}
	
	// 2. �ڷ� ������ �����ϴ� ���.
	else
	{
		
		// �����ڿ��� �ִٸ�. 
		if( avail && m_bm.gathered_data == LEFT_COMPACT  )
		{
			// set bm
			x = GetUsingResource(&m_bm);
			for( loop = x ; loop < x + MIN(avail, nCount); loop++)
				SetResource( &m_bm, loop);

			// �ڷ� ī��
			memcpy(m_data + tuple_size * x, m_tuple, tuple_size *MIN(avail, nCount) );
				
			
		}
		else
			return FAIL;


	}
	
	return  SUCCESS;

}

// ok
/*-----------------------------------------
1. ��� : �����ϴ� nindex��°�� data�� Update
2. parameter

3. return 

4. example

  	ptArray.Add(CPoint(10,20));   // Element 0
	ptArray.Add(CPoint(30,40));   // Element 1 (will become (50,60))
	ptArray.SetAt(1, CPoint(50,60));   // update New element 1
-------------------------------------------*/
int CArrayData::SetAt(int nindex, void *m_tuple)
{
	
	Res_status_type  status;
	if( nindex < 0 || nindex >= m_bm.max_resource)
		return FAIL;
	
	GetStatus(&m_bm, nindex, &status);
	if( status == NOT_USING)
		return FAIL;
	
	memcpy(m_data + tuple_size*nindex, m_tuple, tuple_size );
	
	return SUCCESS;
}

// ok
int CArrayData::GetAt(int nindex, void *m_tuple)
{
	Res_status_type  status;
	if( nindex < 0 || nindex >= m_bm.max_resource)
		return FAIL;
	
	GetStatus(&m_bm, nindex, &status);
	if( status == NOT_USING)
		return FAIL;
	
	memcpy(m_tuple, m_data + tuple_size*nindex,  tuple_size );
	return SUCCESS;
	
}

//////////////////////////////////////////////////////////////////
int CArrayData::FileSave(const char *filename)
{
	FILE *out;

	if ( (out = fopen(filename, "wb") ) == NULL )
		return FALSE;
	
	FileWrite( out );
	
	fclose(out);
	return TRUE;
}

int CArrayData::FileLoad(const char *filename)
{
	FILE *in;
	
	if ( (in = fopen(filename, "rb") ) == NULL )
		return FALSE;
	
	FileRead( in );
	
	fclose(in);
	return TRUE;
}

void CArrayData::Write_Tuples(FILE *out)
{
	// tuple size
	fwrite( &tuple_size, sizeof(int), 1, out ); 

	// write tuples
	fwrite(m_data, tuple_size * m_bm.max_resource, 1, out );
}

void CArrayData::Read_Tuples(FILE *in)
{
	// tuple size
	fread( &tuple_size, sizeof(int), 1, in );

	// alloc and write tuples
	AllocData(&m_data, 	m_bm.max_resource , tuple_size );
	fread(m_data, tuple_size * m_bm.max_resource, 1, in );
}

void CArrayData::FileWrite(FILE *out)
{
	
	// 1. Write BM
	FileWriteBM( &m_bm, out);
	
	// 2. Write Data
	Write_Tuples(out);
	
	
}

void CArrayData::FileRead(FILE *in)
{
	Close();
	FileReadBM(&m_bm, in);
	
	// 2. data size
	Read_Tuples(in);
}

//////////////////////////////////////////////////////////////////
/*-----------------------------------------
1. ��� : 

2. parameter
1) Res_status_type status 
2) int from_no : zero-based number
3) int to_no : zero-based number

3. return 

4. example


-------------------------------------------*/
int CArrayData::FindIndexWithStatus(Res_status_type status, int from_no, int to_no)
{
	int  x;
	Res_status_type  s;
	
	if( from_no < 0)
		from_no = 0;
	if ( to_no >= m_bm.max_resource )
		to_no = m_bm.max_resource - 1;
	
	for( x = from_no;  x <= to_no;  x++ )
	{
		GetStatus(&m_bm, x, &s);
		if( s == status )
			return x;
	}
	
	return FAIL;
	
}



int CArrayData::Compact(COMPACT_Type type)
{
	switch(type) 
	{
	case COMPACT_SEQUENCE:
		m_bm.gathered_data = LEFT_COMPACT;
		return Compact_Sequence();
		break;
	case COMPACT_FROM_END_TO_START:
		m_bm.gathered_data = LEFT_COMPACT;
		return Compact_From_End_To_Start();
		break;
	default:
		break;
	}
	return SUCCESS;
}

int CArrayData::Compact_From_End_To_Start()
{

	// data full ?

	// data empty?

	// �ڿ� �ִ� tuple�� �տ� ����� �ִ� ��.

	return 1;

}

int CArrayData::Compact_Sequence()
{
	int cur_empty = 0, cur_using = -1;
	
	// data full ?
	if( !GetAvailableResource(&m_bm) )
		return SUCCESS;
	
	// data empty?
	if ( !GetCurrent())
		return SUCCESS;

	do
	{
	
		//  �� tuple �ڿ� �����鼭 ���� ��ó�� �ִ� ������� Ʃ���� �ű��.
		cur_empty = FindIndexWithStatus( NOT_USING, cur_empty, GetMaxRes() );
		
		if( cur_empty != FAIL)
			cur_using = FindIndexWithStatus( USING,		cur_empty, GetMaxRes() );
		else 
			break;
		
		if ( cur_using != FAIL )
		{
			// Bitmap ��ġ �ٲٱ�.
			PutResource( &m_bm, cur_using);
			SetResource( &m_bm, cur_empty);


			// ���� ����Ÿ �̵�
			// memcpy( GetData(cur_empty), GetData(cur_using), tuple_size );
			MoveData( (char*)GetData(cur_empty), (char*)GetData(cur_using), tuple_size );
			memset( GetData(cur_using), 0x0, tuple_size );

			// 
			cur_empty++ ;

		}
		
	} while( cur_empty != FAIL && cur_using != FAIL);



	m_bm.last_freenum = m_bm.cur_resource -1;
	return SUCCESS;

}




int CArrayData::MoveData(char *target, char *source, int ntuplesize, int ncount)
{
	int x;

	if( source == target || ncount <= 0)
		return FAIL;

	// 1. source �ּ� < target�ּ��̸� �� Ʃ�ú��� ����.
	if( source < target)
	{
		for( x = ncount -1; x >=0; x--)
		{
			memcpy( target + ntuplesize*x, source +ntuplesize*x, ntuplesize);
		}

		return SUCCESS;

	}

	// 2. source �ּ� > target�ּ��̸� �� Ʃ�ú��� ����.
	else
	{

		for( x = 0; x < ncount ; x++ )
		{
			memcpy( target + ntuplesize*x, source +ntuplesize*x, ntuplesize);
		}
		
		return SUCCESS;

	}

}

void CArrayData::Sort(COMPARE cmp)
{
	
	// 1. compact
	Compact();


	quicksort(m_data, m_bm.cur_resource, tuple_size, compare);

}

void CArrayData::Sort()
{
	if(compare)
	{
		Sort(compare);
	}
}

void CArrayData::SetSortFunction(COMPARE cmp)
{
	compare = cmp;
}

COMPARE CArrayData::GetSortFunction()
{
	return compare;
}






int CArrayData::GetTupleSize() const
{
	return tuple_size;
}



BM* CArrayData::GetBMPtr() 
{
	return &m_bm;
}
