#include <string.h>
#include "sql_lex.h"
#include "token.h"

// #define MAX_KEYWORD  100
STR_Type m_all_keyword[MAX_KEYWORD] =
{
	{"insert",		INSERT },  // 0
	{"delete",		DELETE },  
	{"select",		SELECT },
	{"update",		UPDATE },
	{"from",		FROM },
	{"where",		WHERE},
	{"'",			S_QUOTE }, // Single quotes '
	{",",			COMMA},
	{"(",			L_PAREN }, // Left Parenthesis
	{")",			R_PAREN },
	{";",			SEMICOLON },

	{"and",			AND },
	{"or",			OR },		// 10

	{"+",			PLUS },
	{"-",			MINUS },
	{"*",			MULTIPLY },
	{"/",			DIVIDE },

	{"sum",			SUM },
	{"avg",			AVG },
	{"min",			MIN_AG },
	{"max",			MAX_AG },
	{"count",		COUNT },
	

	{"<>",			NE },	
	{"!=",			NE },
	{"=",			EQ },
	{">",			GT },
	{"<",			LT },
	{">=",			EGT },	// 20
	{"<=",			ELT },

	{"not",			NOT },
	
	{"exist",		EXIST },
	{"not exist",	NOT_EXIST },

	{"union",		UNION },
	{"intersect",	INTERSECT }, 

	{"except",		EXCEPT	},
	{"like",		LIKE },
	{"not like",	NOT_LIKE },
	
	{"in",			IN },
	{"not in",		NOT_IN },		// 30

	{"having",		HAVING },
	{"order by",	ORDER_BY },
	{"group by",	GROUP_BY },  

};


Pattern_Type m_all_Pattern_keyword =
{
	MAX_KEYWORD,
	{
	{"insert",		INSERT },  // 0
	{"delete",		DELETE },  
	{"select",		SELECT },
	{"update",		UPDATE },
	{"from",		FROM },
	{"where",		WHERE},
	{"'",			S_QUOTE }, // Single quotes '
	{",",			COMMA},
	{"(",			L_PAREN }, // Left Parenthesis
	{")",			R_PAREN },
	{";",			SEMICOLON },

	{"and",			AND },
	{"or",			OR },		// 10

	{"+",			PLUS },
	{"-",			MINUS },
	{"*",			MULTIPLY },
	{"/",			DIVIDE },

	{"sum",			SUM },
	{"avg",			AVG },
	{"min",			MIN_AG },
	{"max",			MAX_AG },
	{"count",		COUNT },
	

	{"<>",			NE },	
	{"!=",			NE },
	{">=",			EGT },	// 20
	{"<=",			ELT },
	{"=",			EQ },
	{">",			GT },
	{"<",			LT },



	
	{"not exist",	NOT_EXIST },
	{"exist",		EXIST },
	

	{"union",		UNION },
	{"intersect",	INTERSECT }, 

	{"except",		EXCEPT	},
	{"not like",	NOT_LIKE },
	{"like",		LIKE },

	{"not in",		NOT_IN },		// 30
	{"in",			IN },
	

	{"having",		HAVING },
	{"order by",	ORDER_BY },
	{"group by",	GROUP_BY },  

	{"not",			NOT },
	}
};

CArrayEx m_all_keyword_array;

//////////////////////////////////////////////////////////////////////////

// #define  MAX_AGGREATION     5
STR_Type m_aggregate_keyword[MAX_AGGREATION] =
{
	{"sum",		SUM },
	{"avg",		AVG },
	{"min",		MIN_AG },
	{"max",		MAX_AG },
	{"count",	COUNT }
};

CArrayEx m_aggregate_array;

//////////////////////////////////////////////////////////////////////////

// #define  MAX_RELATION     9
STR_Type m_relative_keyword[MAX_RELATION] =
{
	{"<>",			NE },	
	{"!=",			NE },
	{"=",			EQ },
	{">",			GT },
	{"<",			LT },
	{">=",			EGT },	// 20
	{"<=",			ELT },
	{"like",		LIKE },
	{"not like",	NOT_LIKE },
};

CArrayEx m_relative_array;

//////////////////////////////////////////////////////////////////////////

// #define  MAX_CONJUNCTION    2
STR_Type m_conjunction_keyword[MAX_CONJUNCTION] =
{
	{"and",			AND },
	{"or",			OR },
};

CArrayEx m_conjunction_array;


//////////////////////////////////////////////////////////////////////////
// #define  MAX_IN    2
STR_Type m_in_keyword[MAX_IN] =
{
	{"in",			IN },
	{"not in",		NOT_IN }
};
CArrayEx m_in_array;
//////////////////////////////////////////////////////////////////////////

static int Compare_token( const void * a, const void *b)
{
	return strcmp( (( STR_Type * )a)->name, (( STR_Type * )b)->name );
}


/*
1. ��   �� : KeyWord����.
*/
void Init_Keyword(CArrayEx *m_array, STR_Type *m_keyword , int keyword_count)
{
	int x;
	
	// KeyWord����.
	m_array->Init( keyword_count, sizeof(STR_Type) );
	m_array->SetSortFunction( Compare_token );

	m_array->InsertHead( m_keyword, keyword_count);


	m_array->Sort();

	for ( x = 0 ; x < m_array->GetCurrent(); x++)
	{
		STR_Type *p = (STR_Type *)m_array->ElementAt(x);
		if(p)
			printf("[%d] %s %d\n", x, p->name, p->type );
	}


}

Token_Type Compare_Keyword( CArrayEx *m_keyword,  char * needle )
{
	STR_Type *p;
	if( ( p = (STR_Type *)m_keyword->ElementAt(  m_keyword->FindEx( needle ) ) ) == NULL)
		return NONE;
	
	
	return p->type;
}

/*
1. ��   �� : Token�� ���¼� �м��Ѵ�. 


	{"not exist",	NOT_EXIST },
	{"not like",	NOT_LIKE },
	{"not in",		NOT_IN },
*/
void Not_Lexical( CArrayEx *m_token, CArrayEx *m_keyword )
{
	int x = 0;
	Token_Attr *current, *next;
	Token_Type  current_type, next_type;

	for( x = 0; x < m_token->GetCurrent(); x++)
	{
		// ���� �Ѱ� ���� ����.
		if(( current = (Token_Attr *)m_token->ElementAt(x) )== NULL)
			return;
		
		if(  (current_type = Compare_Keyword( m_keyword, current->name) ) != NONE)
		{
			// not in, not exist, not like
			if(current_type == NOT )	
			{
			
				// next ���� �Ѱ� ���� ����.
				if(( next = (Token_Attr *)m_token->ElementAt(++x) )== NULL)
					return;

				next_type = Compare_Keyword( m_keyword, next->name);
				if(  next_type != IN && next_type != EXIST && next_type != LIKE )
				{
					x--;
					continue;
				}

				switch( next_type ) 
				{
					case  EXIST :
					{
						// current "not exist"�� ����� type�� NOT_EXIST
						current->type = NOT_EXIST;
						strcat(current->name, " exist");
						m_token->RemoveAtEx( x);
						m_token->SetSize(m_token->GetCurrent());
						x--;
					}break;
					case  LIKE:
					{
						current->type = NOT_LIKE;
						strcat(current->name, " like");
						m_token->RemoveAtEx( x);
						m_token->SetSize(m_token->GetCurrent());
						x--;
					}break;
					case  IN:
					{	
						current->type = NOT_IN;
						strcat(current->name, " in");
						m_token->RemoveAtEx( x);
						m_token->SetSize(m_token->GetCurrent());
						x--;
					}break;
					default:
						break;
				}
			}
			else
				current->type = current_type;
		}
			

	}
}


/*
1. ��   �� : Token�� ���¼� �м��Ѵ�. 


	{"not exist",	NOT_EXIST },
	{"not like",	NOT_LIKE },
	{"not in",		NOT_IN },
*/
void SQL_Lex( CArrayEx *m_token, CArrayEx *m_keyword )
{
	int x;
	Token_Attr * current;
	Token_Type type;

	// SQL keyword�� ��� array�� ����
	Init_Keyword( &m_all_keyword_array,		m_all_keyword, MAX_KEYWORD);
	Init_Keyword( &m_aggregate_array,		m_aggregate_keyword,	MAX_AGGREATION);
	Init_Keyword( &m_relative_array,		m_relative_keyword,		MAX_RELATION);
	Init_Keyword( &m_conjunction_array,		m_conjunction_keyword,	MAX_CONJUNCTION);
	Init_Keyword( &m_in_array,				m_in_keyword,			MAX_IN);

	// ��� Ÿ�� ����.
	for (x = 0 ; x < m_token->GetCurrent(); x++)
	{
		if(  (current = ( Token_Attr * )m_token->ElementAt( x ) )	== NULL )
			return;

		// set the type of token.
		if( (type = Compare_Keyword( m_keyword,  current->name )) != NONE)
			current->type = type;
		else
		{
			// DIGIT
			if( IS_DIGIT_STRING(current->name))
				current->type = DIGIT;

			// HEXA
			else if( IS_HEXA_STRING(current->name))
				current->type = HEXA;

			else
				current->type = STRING;
		}
	}

	// not in�� �� ���ڿ��� ����
	Not_Lexical( m_token, m_keyword );
}