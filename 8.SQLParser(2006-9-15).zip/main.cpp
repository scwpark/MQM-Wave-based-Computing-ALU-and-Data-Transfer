#include <stdio.h>
#include <conio.h>
#include <string.h>
#include "token.h"
#include "array_extern.h"
#include "query_select.h"


#define MAIN1 // test1()�� �Ϸ��� MAIN1, test2()�� �ҷ��� MAIN2


#define MAX_LINE_LENGTH         512

#ifdef MAIN1
void main()
#else
void test1()
#endif	
{
	// [1]. Data
	int x=0;
	int  index =0;
	int  num_of_token =0;
	char token[50];
	int  token_length =0;	
	CArrayEx  array_token ;
	Token_Attr token_atr, *p;
	
	// char message[MAX_LINE_LENGTH] = "   \t0x1234\n int\tCString::GetString(char a)>=\n    ";
	// char message[MAX_LINE_LENGTH] = "select a, b from db where a>=3.4 and b <=5;   ";
	// char message[MAX_LINE_LENGTH] = "select a, b from db where a not  in( select a1 from db2 where a1 <> 2);   ";
	char message[MAX_LINE_LENGTH] = "select a, b from db where a not  in( select a1 from db2 where a1 in (select a2 from db3 where a2 <=5) );   ";

	

	// [2].
	FILE * input;
	
	// [2].
	// [2-1]. File Open
#if 0
	if((input = fopen("a.txt", "r")) == NULL)
	{
		printf("\nFile Open Error\n");
		return ;
	}
#endif

	// [2-1]. line���� token. Test
	// gets(message);
	// 

	array_token.Init( 1, sizeof(Token_Attr) );

	// [2-2]. line���� �Ľ�. Test
#if 0
	while(fgets(message, 500,  input))
	{
#endif	
		printf(message);
		index =0;
		while(message[index] != NULL && strlen(message) >index )	
		{	
			// [2-1-1]. line������ ��ū�� ��´�.
			GET_TOKEN(message,&index,token,&token_length , &G_Delimiter );
			token_atr.type = STRING;
			if (token_length >= MAX_ATTRIBUTE_NAME_LEN -1)
			{
				memcpy( token_atr.name, token, MAX_ATTRIBUTE_NAME_LEN -1);
				token_atr.name[MAX_ATTRIBUTE_NAME_LEN - 1] = NULL;
			}
			else
				strcpy( token_atr.name, token);
			if( token_length > 0)
			{
				
				if( array_token.IsFull())
					array_token.SetSize( array_token.GetMaxRes() + 10 );
				array_token.InsertTail( &token_atr );
			}
			
			
			if(token_length !=0)
			{
				printf("\nnum[%d] : token[%s]is a %s, message[index(%d)] token_length(%d)\n",
					num_of_token++, token_atr.name, 
					IS_HEXA_STRING(token)==HEXA_DIGIT_STRING?"hexa":"no" , 
					index,token_length);
			}
		}
		
		printf("\n press any key");	
		//getch();
#if 0		
	}
#endif
	
#if 0
	fclose(input);
#endif

	// [2-2]. lexical
	SQL_Lex( &array_token, &m_all_keyword_array);
	printf("\n");
	for( index = 0 ; index < array_token.GetCurrent();  index++ )
	{
		p =(Token_Attr*)array_token.ElementAt(index);
		printf("[%d] %s %d\n", index, p->name , p->type);
	}


	// [3]. Parser
	select_main(&array_token);

}
	
