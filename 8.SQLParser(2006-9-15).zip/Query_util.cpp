#include "sql_lex.h"
#include "query_util.h"

#include <string.h>

///////////////////////////////////////////////////////////////////////////////////////////////////////
// [1]. �Ľ̵����Լ���
///////////////////////////////////////////////////////////////////////////////////////////////////////
/*---------------------------------------------------------------------
1. ��	  �� :  token���� ��� �ִ� m_token_pos����  m_pattern_type��
				Terminal code�� �ִ��� Ȯ���Ѵ�.
				
				""�� NON Terminal�� ������ �ʴ´�.
2. Parameter :

3. return	 : 
---------------------------------------------------------------------*/
int Find_Pattern( Token_Pos *m_token, Pattern_Type *m_pattern_type  )
{
	int loop;
	Token_Attr * current;
	int			 backup_x = m_token->array_x[0];

#if 1

	// token�� �Ѱ��� �������鼭 Ÿ���� �´��� Ȯ��.
	for( loop = 0; loop < m_pattern_type->count; loop++ )
	{
		if( ( current = ( Token_Attr * ) m_token->token_array->ElementAt( m_token->array_x[0]++  ) ) == NULL )
			RETURN_FALSE( m_token, backup_x );
		
		if (!strcmp( m_pattern_type->pattern[loop].name, "" ) )
			continue;
		
		// ���ڿ��� �ٸ��ٸ� 
		if( strcmp(current->name, m_pattern_type->pattern[loop].name) )
			RETURN_FALSE( m_token, backup_x );
		else 
			return TRUE;
	}

	// ������ ������ġ�� array_x��ġ �̵�
	// m_token->array_x[0]--;
	
	return TRUE;

#else

	// token�� �Ѱ��� �������鼭 Ÿ���� �´��� Ȯ��.
	for( loop = 0; loop < m_pattern_type->count; loop++ )
	{
		if( ( current = ( Token_Attr * ) m_token->token_array->ElementAt( m_token->array_x[0]++  ) ) == NULL )
			RETURN_FALSE( m_token, backup_x );

		 if (m_pattern_type->pattern[loop].type == NONE )
			 continue;

		 if ( current->type != m_pattern_type->pattern[loop].type )
			 RETURN_FALSE( m_token, backup_x );
	}
	
	// ������ ������ġ�� array_x��ġ �̵�
	// m_token->array_x[0]--;
	
	return TRUE;

#endif

}



int Find_Pattern( Token_Pos *m_token, char *m_pattern_type  )
{

	Token_Attr * current;
	int			 backup_x = m_token->array_x[0];
	
	// token�� �Ѱ��� �������鼭 Ÿ���� �´��� Ȯ��.
	if( (current = ( Token_Attr * ) m_token->token_array->ElementAt( m_token->array_x[0]++  ) ) == NULL)
		RETURN_FALSE( m_token, backup_x );
		
	if ( !strcmp(current->name, m_pattern_type) )
		return TRUE;	
	
	RETURN_FALSE( m_token, backup_x );
}



/*------------------------------------------------------------------------------------------
1. ��� :	[ TERMINAL  NONTERMINAL   TERMINAL] �� parsingó���Ѵ�. [ �Ľ̿� �߿��� �ڵ�]
��)  select  * from
1) start[m_start_pattern]	: select
2) nonterminal				: *
3) end	 [m_end_pattern]	: from
------------------------------------------------------------------------------------------*/
int Start_Nonterm_End_Parser(	Token_Pos *m_token,  CArrayEx *keyword_list,  
								Pattern_Type *m_start_pattern/* select */, Pattern_Type *m_end_pattern,/* from */ 
								Token_Attr *nonterminal )
{
	Token_Attr * current ;
	CArrayEx *array = m_token->token_array;
	int      *x		= m_token->array_x;
	int		 backup_x = *x;

	// [1]. find Terminal(start pattern)
	if( m_start_pattern )
		if( Find_Pattern( m_token, m_start_pattern)== FALSE)
			RETURN_FALSE(m_token, backup_x);


	// [2]. find nonterminal
	if( (current = ( Token_Attr * ) array->ElementAt( (*x)++ ) ) == NULL )
		RETURN_FALSE(m_token, backup_x);

	// return nonterminal
	memcpy( nonterminal, current, sizeof(Token_Attr) );
	

	// [3]. find Terminal(end pattern)
	if( m_end_pattern )
		if( Find_Pattern( m_token, m_end_pattern)== FALSE)
			RETURN_FALSE(m_token, backup_x);

	return TRUE;
}

int Start_Nonterm_End_Parser(	Token_Pos *m_token,		CArrayEx *keyword_list,  
								char *m_start_pattern,	char *m_end_pattern,
								Token_Attr *nonterminal )
{
	Token_Attr * current ;
	CArrayEx *array = m_token->token_array;
	int      *x		= m_token->array_x;
	int		 backup_x = *x;
	
	
	// [1]. find Terminal(start pattern)
	if( m_start_pattern )
		if( Find_Pattern( m_token, m_start_pattern)== FALSE)
			RETURN_FALSE(m_token, backup_x);
	
	
	// [2]. find nonterminal
	if( (current = ( Token_Attr * ) array->ElementAt( (*x)++ ) ) == NULL )
		RETURN_FALSE(m_token, backup_x);
	
	// return nonterminal
	memcpy( nonterminal, current, sizeof(Token_Attr) );
	
	
	// [3]. find Terminal(end pattern)
	if( m_end_pattern )
		if( Find_Pattern( m_token, m_end_pattern)== FALSE)
			RETURN_FALSE(m_token, backup_x);
	
	return TRUE;
}


/*------------------------------------------------------------------------------------------
1. ��� :	[ TERMINAL  NONTERMINAL  END_TERMINAL] �� parsingó���Ѵ�. [ �Ľ̿� �߿��� �ڵ�]
������ END_Terminal�� �� �� �ִ� ���� ������ ã��
��)  atr1 [ >= | <= | > | < | <> ]  10
��)  atr1 [ , | from ]
1) start[m_start_pattern]	: select
2) nonterminal				: *
3) end	 [m_end_pattern]	: from
------------------------------------------------------------------------------------------*/
int Start_Nonterm_End_Parser(	Token_Pos *m_token,  CArrayEx *keyword_list,  
								Pattern_Type *m_start_pattern, CArrayEx *m_end_pattern_list, 
								Token_Attr *nonterminal , Token_Attr *endterminal)
{
	Token_Attr * current ;
	CArrayEx *array = m_token->token_array;
	int      *x		= m_token->array_x;
	int		 backup_x = *x;
	int		 loop ;

	Pattern_Type m_end;

	// [1]. find Terminal(start pattern)
	if( m_start_pattern )
		if( Find_Pattern( m_token, m_start_pattern)== FALSE)
			RETURN_FALSE(m_token, backup_x);


	// [2]. find nonterminal
	if( (current = ( Token_Attr * ) array->ElementAt( (*x)++ ) ) == NULL )
		RETURN_FALSE(m_token, backup_x);

	// return nonterminal
	memcpy( nonterminal, current, sizeof(Token_Attr) );
	

	// [3]. find Terminal(end pattern)
	m_end.count = 1;
	for ( loop = 0 ;  loop < m_end_pattern_list->GetCurrent(); loop++ )
	{
		if( ( current = (Token_Attr*) m_end_pattern_list->ElementAt(loop) ) == NULL )
			RETURN_FALSE( m_token, backup_x );

		strcpy( m_end.pattern[0].name , current->name );
		
		if( Find_Pattern( m_token, &m_end ) == TRUE)
		{

			// return endterminal
			memcpy( endterminal, current, sizeof(Token_Attr) );

			return TRUE;
		}
	}

	RETURN_FALSE(m_token, backup_x);
}
