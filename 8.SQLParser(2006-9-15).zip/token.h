#ifndef  _TOKEN_H_
#define  _TOKEN_H_

#include "sql_lex.h"

#ifndef TRUE
#define TRUE		1
#endif

#ifndef FALSE
#define FALSE		0
#endif

#define SUCCESS		TRUE
#define FAIL		-1



//////////////////////////////////////////////////////////////////////////
#define		MAX_DELIMITER		50
#define		MAX_DELIMITER_LEN	50
typedef struct 
{
	int count;
	char str[MAX_DELIMITER][MAX_DELIMITER_LEN];
} Delimiter_Type;  // parser�� ���� Ư�� ��ڿ� �� ��ڸ� ���ϱ����� ����.

extern Delimiter_Type G_Delimiter;
extern Delimiter_Type G_Skip;

//void  GET_TOKEN(char *line,int* offset,char *token,int *token_length)  ;
void  GET_TOKEN(char *line,int* offset,char *token,int *token_length, Delimiter_Type * m_delimiter);
// void  GET_TOKEN(char *line,int* offset,char *token,int *token_length, Token_Type *token_type , Pattern_Type * m_delimiter);



//////////////////////////////////////////////////////////////////////////
#define DIGIT_STRING 	   TRUE
#define NO_DIGIT_STRING    -1
int IS_DIGIT_STRING(char *token);

//////////////////////////////////////////////////////////////////////////
#define HEXA_DIGIT_STRING     TRUE
#define NO_HEXA_DIGIT_STRING  -1 
int IS_HEXA_STRING(char *token);

//////////////////////////////////////////////////////////////////////////
#define IS_SKIP(x) (x==' '||x=='\t' || x =='\n' || x== 13)
#define IS_EOL( c, d)  ( (c)=='\n'|| (c)==0 || ( (c)==13 && (d)=='\n'))
#define IS_DELI(x)  (x=='/'||x==':'||x==','||x==';'||x=='='||x=='('||x==')' )


#define D_GET_TOKEN(line,offset,token,token_length)\
do{\
	token_length=0;\
	for(;IS_SKIP(line[offset]);(offset)++)\
		;\
	if( IS_EOL(line[offset],line[offset+1]) )\
	{\
		token[0] = NULL;\
		token_length = 0;\
		break;\
	}\
	while( !IS_EOL(line[offset],line[offset+1])  ) \
	{\
		token[token_length++]=line[offset++];\
		if(IS_DELI(line[offset])  || IS_DELI(line[offset-1]) || IS_SKIP(line[offset]))\
			break;\
	}\
		token[token_length]=0;\
	\
}while(0) 


void mkdir_test();

#endif