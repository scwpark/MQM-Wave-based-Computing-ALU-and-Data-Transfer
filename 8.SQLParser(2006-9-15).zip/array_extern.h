#ifndef  _ARRAY_EXTERN_H_

#define  _ARRAY_EXTERN_H_

// arrayDB�� sort���� �Լ� header file
// #include "array_db\mytemplates.h"
// #include "array_db\ArrayData.h"
#include "array_db\bitset.h"


#include "array_db\data_type.h"
#include "array_db\mytemplates.h"
#include "array_db\arraydata.h"
#include "array_db\arrayex.h"
#include "array_db\binarysearch.h"
#include "array_db\compare.h"
#include "array_db\heapsort.h"
#include "array_db\quicksort.h"


#endif