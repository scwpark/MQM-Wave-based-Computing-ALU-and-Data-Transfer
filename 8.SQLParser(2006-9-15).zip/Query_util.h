#ifndef _QUERY_UTIL_H_

#include "array_extern.h"
#include "sql_lex.h"

typedef struct 
{
	CArrayEx *token_array;	// void *
	int *array_x;		// token array�� x��°���� �Ľ��Ͽ� �Ľ��� ��ġ������ ������ �ݿ��ȴ�.
	int retry_x;		// *array_x�� �Ľ� �������� ����Ѵ�. �Ľ̽��н� retry����.
} Token_Pos;


#define   RETURN_FALSE(m_token, backup_x)		\
do{												\
	((Token_Pos *)m_token)->retry_x = ((Token_Pos *)m_token)->array_x[0] = backup_x;	\
	return FALSE;								\
}while(0)


int Find_Pattern( Token_Pos *m_token, Pattern_Type *m_pattern_type  );
int Find_Pattern( Token_Pos *m_token, char *m_pattern_type  );


int Start_Nonterm_End_Parser(	Token_Pos *m_token,				CArrayEx *keyword_list,  
								Pattern_Type *m_start_pattern,	Pattern_Type *m_end_pattern,
								Token_Attr *nonterminal );


int Start_Nonterm_End_Parser(	Token_Pos *m_token,		CArrayEx *keyword_list,  
								char *m_start_pattern,	char *m_end_pattern,
								Token_Attr *nonterminal );

int Start_Nonterm_End_Parser(	Token_Pos *m_token,  CArrayEx *keyword_list,  
							 Pattern_Type *m_start_pattern, CArrayEx *m_end_pattern_list, 
							 Token_Attr *nonterminal , Token_Attr *endterminal);



#endif
