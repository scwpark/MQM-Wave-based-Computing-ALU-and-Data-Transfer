#include <stdio.h>
#include <string.h>


#include "array_extern.h"
#include "sql_report.h"
#include "query_util.h"
#include "query_select.h"



/*---------------------------------------------------------------------
1. ����
1.1. select structure����
: ��� case�� select �Ľ� ����� ���� structure ����
1) �Ľ��ڵ�� �켱 �Ľ��� �Ǵ����� Ȯ���ϰ� structure�� ���� �ʴ´�.
2) �Ľ� ����� case���� ��������� return�Ѵ�.
---------------------------------------------------------------------*/
Pattern_Type	select_pattern
={
	1,
	SELECT,
};

Pattern_Type	from_pattern
={
	1,
	FROM,
};

///////////////////////////////////////////////////////////////////////////////////////////////////////
// [1]. select �Ľ�.
///////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////

/*------------------------------------------------------------------------------------------
1. ��� :	select�� from������ attributeó�� �ϴ� �Լ�.
��)  select  [ atr1,  atr2 ] from
------------------------------------------------------------------------------------------*/
int Attribute1_From( Token_Pos *m_token, CArrayEx *all_keyword, CArrayEx *aggregate_keyword,  
							 Pattern_Type *m_start_pattern/* select */, Pattern_Type *m_end_pattern,/* from */ 
							 CATR *m_CATR , int atr_count , QUERY_Datum *m_query_datum )
{
	Token_Attr * current , *next;
	CArrayEx *array = m_token->token_array;
	int      *x = m_token->array_x;
	int		 backup_x = *x;
	
	int y = 0;
	while ( (current = ( Token_Attr * ) array->ElementAt( (*x)++ ) ) = NULL)  
	{
		// [1]. *
		

		// [2]. atr1, atr2
		// 1. attribute
		memcpy( &m_query_datum->attrib_name[y++], current, sizeof(Token_Attr) ); 
		// m_query_datum->count = y;
		
#if 0	// 2. check if attribute
		if( IsAttribute(m_CATR, atr_count, current) >= 0 )
			current->type = ATTRIBUTE_NAME;
		else
			RETURN_FALSE( m_token, backup_x );
#endif
		
		// 3. from
		backup_x = *x;
		if( Find_Pattern(m_token, m_end_pattern))
			return TRUE;

		// 3-2. attribute list COMMA == ,
		*x = backup_x;
		if( (next = ( Token_Attr * ) array->ElementAt( (*x)++ ) ) == NULL)
			RETURN_FALSE( m_token, backup_x );
		if (next->type == COMMA )
		{
			
			continue;
		}
		RETURN_FALSE( m_token, backup_x );

	}
	
	return TRUE;
}

/*------------------------------------------------------------------------------------------
1. ��� :	select�� from������ attributeó�� �ϴ� �Լ�.
			m_token->array_x�� ��ġ�� "from" ���ڿ� �������� �̵��Ǿ� �ִ�.
��)  select  [ sum(attr1), avg(attr2), attr3, attr4 ] from
------------------------------------------------------------------------------------------*/
int Attribute2_From( Token_Pos *m_token,  CArrayEx *all_keyword, CArrayEx *aggregate_keyword,   
					Pattern_Type *m_start_pattern/* select */, Pattern_Type *m_end_pattern,/* from */ 
					CATR *m_CATR , int atr_count , QUERY_Datum *m_query_datum )
{
	Pattern_Type  m_start, m_end;
	int loop;
	int backup_x = m_token->array_x[0];
	Token_Attr * pattern;
	Token_Attr nonterminal;

	int y=0;

	while(1)
	{
		//////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////
		for( loop = 0 ; loop < aggregate_keyword->GetCurrent();  loop++)
		{
		
			if( ( pattern = (Token_Attr *)aggregate_keyword->ElementAt(loop) ) == NULL )
				RETURN_FALSE(m_token, backup_x);

			//////////////////////////////////////////////////////////////////////////
			// [ sum( attr1 ), ]
			m_start.count = 2;
			strcpy( m_start.pattern[0].name, pattern->name );
			strcpy( m_start.pattern[1].name, "(" );
			
			m_end.count = 2;
			strcpy( m_end.pattern[0].name, ")"		);
			strcpy( m_end.pattern[1].name, ","	);
			
			// get nonterminal
			if( Start_Nonterm_End_Parser(m_token, all_keyword, &m_start, &m_end, &nonterminal) == TRUE)
			{
				// store nonterminal
				y++;

				break ;
			}

			//////////////////////////////////////////////////////////////////////////
			// [ sum( attr1 ) from ] 
			strcpy( m_end.pattern[1].name, "from"	);
				
			// get nonterminal
			if( Start_Nonterm_End_Parser(m_token, all_keyword, &m_start, &m_end, &nonterminal) == TRUE)
			{
				// store nonterminal
				y++;
				
				return TRUE;
			}		

			
			
		}

		//////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////
		// [ attr1, ]
		m_start.count	= 0;
		
		m_end.count		= 1;
		strcpy( m_end.pattern[0].name, ","	);
		
		// get nonterminal
		if( Start_Nonterm_End_Parser(m_token, all_keyword, &m_start, &m_end, &nonterminal) == TRUE)
		{
			// store nonterminal
			y++;
			
			continue ;
		}


		//////////////////////////////////////////////////////////////////////////
		// [ attr1 from ]
		m_start.count	= 0;
		
		m_end.count		= 1;
		strcpy( m_end.pattern[0].name, "from"	);
		
		// get nonterminal
		if( Start_Nonterm_End_Parser(m_token, all_keyword, &m_start, &m_end, &nonterminal) == TRUE)
		{
			// store nonterminal
			y++;
			
			return TRUE ;
		}
		
		
		//////////////////////////////////////////////////////////////////////////
		// ��� �Ϳ��� �ش���� ������
		RETURN_FALSE(m_token, backup_x);

	}

	return TRUE;
}

/*------------------------------------------------------------------------------------------
1. ��� :	select�� from������ attributeó�� �ϴ� �Լ�.
��)  [select  atr1,  atr2  from ]
------------------------------------------------------------------------------------------*/
int Select_from_Parser( Token_Pos *m_token,  CArrayEx *all_keyword, CArrayEx *aggregate_keyword,  
						Pattern_Type *m_start_pattern/* select */, Pattern_Type *m_end_pattern,/* from */
						CATR *m_CATR , int atr_count , 
						QUERY_Datum *m_query_datum)
{
	// [1]. compare start pattern
	if( Find_Pattern( m_token, m_start_pattern)== FALSE)
		return FALSE;
	
	// [2]. from������ parsing 
	return Attribute2_From( m_token, all_keyword,	aggregate_keyword, 
							m_start_pattern,		m_end_pattern, 
							m_CATR , atr_count , m_query_datum );


}

/*------------------------------------------------------------------------------------------
1. ��� :	from�� where������ attributeó�� �ϴ� �Լ�.
��)  [from  db1 as nickname1 , db2 as nickname2  where]
------------------------------------------------------------------------------------------*/
int  from_where_Parser( Token_Pos *m_token,  CArrayEx *all_keyword, CArrayEx *aggregate_keyword,
						Pattern_Type *m_start_pattern/* select */, Pattern_Type *m_end_pattern,/* from */
						CATR *m_CATR , int atr_count , 
						QUERY_Datum *m_query_datum)
{	
	Pattern_Type  m_start, m_end;
	int backup_x = m_token->array_x[0];
	Token_Attr nonterminal;
	
	int y=0;
	
	// [1]. compare start pattern("from")
	if( Find_Pattern( m_token, m_start_pattern)== FALSE)
		return FALSE;
	
	// [2]. from���� where������ parsing 
	while(1)
	{
	
		//////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////
		// [1]. [ db1 as nickname1, db2 where ]
		m_start.count	= 0;
		
		m_end.count		= 1;
		strcpy( m_end.pattern[0].name, "as"	);
		
		// get nonterminal
		if( Start_Nonterm_End_Parser(m_token, all_keyword, &m_start, &m_end, &nonterminal) == TRUE)
		{

			// 1. nickname ,
			m_end.count		= 1;
			strcpy( m_end.pattern[0].name, ","	);
			if( Start_Nonterm_End_Parser(m_token, all_keyword, &m_start, &m_end, &nonterminal) == TRUE)
			{

				// store nonterminal
				y++;
			
				continue ;
			}
			
			// 2. nickname from
			m_end.count		= 1;
			strcpy( m_end.pattern[0].name, "where"	);
			if( Start_Nonterm_End_Parser(m_token, all_keyword, &m_start, &m_end, &nonterminal) == TRUE)
			{
				
				// store nonterminal
				y++;
				
				return TRUE ;
			}
		}
		
		
		//////////////////////////////////////////////////////////////////////////
		// [2]. db1 , db2 where
		m_start.count	= 0;
		

		// 1. db1 ,
		m_end.count		= 1;
		strcpy( m_end.pattern[0].name, ","	);
		
		// get nonterminal
		if( Start_Nonterm_End_Parser(m_token, all_keyword, &m_start, &m_end, &nonterminal) == TRUE)
		{
			// store nonterminal
			y++;
			
			continue;
		}
		
		// 2. db2 where
		m_end.count		= 1;
		strcpy( m_end.pattern[0].name, "where"	);
		if( Start_Nonterm_End_Parser(m_token, all_keyword, &m_start, &m_end, &nonterminal) == TRUE)
		{
			
			// store nonterminal
			y++;
			
			return TRUE ;
		}
		
		//////////////////////////////////////////////////////////////////////////
		// ��� �Ϳ��� �ش���� ������
		RETURN_FALSE(m_token, backup_x);
		
	}
	
	return TRUE;
	
}



/*
1. ��� :	where������ ���ǹ� ó�� 
��)  where  [ ( attr1 >= 20 and attr2 <= 30 ) ] ;    where   [ attr1 >= 20 and attr2 <= 30 ; ]
						*/
int where_if_one_process_attribute_value( Token_Pos *m_token,  CArrayEx *keyword_list,  
									Pattern_Type *m_start_pattern/* select */, Pattern_Type *m_end_pattern,/* from */
									CATR *m_CATR , int atr_count , 
									QUERY_Datum *m_query_datum)
{
	Pattern_Type  m_start, m_end;
	int backup_x = m_token->array_x[0];
	CArrayEx  *array = m_token->token_array;
	int * x			 = m_token->array_x;

	Token_Attr nonterminal, endterminal;

	
	int y=0;
	
	// [1]. compare start pattern("where ( ")
	if( Find_Pattern( m_token, m_start_pattern)== FALSE)
		RETURN_FALSE( m_token, backup_x );
	
	// [2]. 
	while(1)
	{

		///////////////////////////////////////////////////////////////////////////////
		// 1. [ attr1 >= ]  data 
		if( Start_Nonterm_End_Parser(m_token,keyword_list, NULL, &m_relative_array,  &nonterminal, &endterminal) == TRUE )
		{
			
			//  attr1 >= [  data and ]
			if ( Start_Nonterm_End_Parser(m_token, keyword_list, NULL, &m_conjunction_array,  &nonterminal, &endterminal) == TRUE )
			{
					
				
				continue;
			}

			// ��� �Ϳ��� �ش� ���� �ʴ´ٸ�.
			// 3. compare end pattern(" ) ; ")
			//  attr1 >= data [ ); ]
			if( Start_Nonterm_End_Parser(m_token, keyword_list, NULL, m_end_pattern ,  &nonterminal) == TRUE )
			{
				return TRUE;
			}
			else
				RETURN_FALSE(m_token, backup_x);

		}
		

		///////////////////////////////////////////////////////////////////////////////
		// 2. [ attr1 in ] ( select �� )
		else if ( Start_Nonterm_End_Parser(m_token, keyword_list, NULL, &m_in_array,  &nonterminal, &endterminal) == TRUE )
		{
			/// these codes is very importants




			
		}
		
		// 3. ��� ��쿡�� �ش���� �ʴ´ٸ� 
		RETURN_FALSE( m_token, backup_x );
	}

}

/*
 where atr1 in ( select * from db where a >=3 ); process
*/
int Where_IN_process_attribute_value( Token_Pos *m_token,  CArrayEx *keyword_list, CArrayEx *aggregate_keyword,
									Pattern_Type *m_start_pattern, Pattern_Type *m_end_pattern,
									CATR *m_CATR , int atr_count , 
									QUERY_Report *m_query_report)
{
	Token_Attr * current , *next;
	

	CArrayEx * array = m_token->token_array;
	int *x			 = m_token->array_x;
	int backup_x = m_token->array_x[0];
	Token_Attr * pattern;
	Token_Attr nonterminal;
	int y = 0;


		// [1]. compare start pattern("where  ")
	if( Find_Pattern( m_token, m_start_pattern)== FALSE)
		RETURN_FALSE( m_token, backup_x );
	
	while ( 1 ) 
	{
		///////////////////////////////////////////////////////////////////////////////
		// 6. token attribute & in etc( not in, exist, not exist ..., )
		if( (current = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
			RETURN_FALSE( m_token, backup_x );
		
		if( (next = ( Token_Attr * ) array->ElementAt( x[0]++) ) == NULL)
			RETURN_FALSE( m_token, backup_x );


		/*
		memcpy( &m_query_datum->where[y].where_1st_attrib_name , current, sizeof(Token_Attr ) );
		m_query_datum->where[y].OP = next->type;
		*/
		switch( next->type   )
		{
			case IN :
			case NOT_IN :
			case EXIST :
			case NOT_EXIST :
			{
				// starts "(" and ends ")"
				if( (current = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
					RETURN_FALSE( m_token, backup_x );
				if(current->type == L_PAREN ) // "("
				{
					
					
					// 7. ")"������ ���ǹ� ó��.
					if( Select_Main_Parser(array, x, keyword_list, aggregate_keyword, m_end_pattern, m_CATR, atr_count, m_query_report) == TRUE)
					{
						return TRUE;
						
					}
				}
				else
					RETURN_FALSE( m_token, backup_x );
			
			}break;
			
			
			default :
			{
			}break;
			
		}
		/*
		m_query_datum->where[y].OP = next->type;
		*/
	}
	RETURN_FALSE( m_token, backup_x );
}

/*------------------------------------------------------------------------------------------
1. ��� :	where�� ó���ϴ� �Լ�.
��)  where (                        );
------------------------------------------------------------------------------------------*/
int  where_L_PAREN_R_PAREN_COMMA_Parser( Token_Pos *m_token,  CArrayEx *keyword_list,  
						Pattern_Type *m_start_pattern/* select */, Pattern_Type *m_end_pattern,/* from */
						CATR *m_CATR , int atr_count , 
						QUERY_Datum *m_query_datum)
{	
	Pattern_Type  m_start, m_end;
	int backup_x = m_token->array_x[0];
	Token_Attr * pattern;
	Token_Attr nonterminal;
	
	int y=0;
	
	// [1]. compare start pattern("where ( ")
	if( Find_Pattern( m_token, m_start_pattern)== FALSE)
		RETURN_FALSE( m_token, backup_x );



	// [3]. compare start pattern(") ; ")
	if( Find_Pattern( m_token, m_start_pattern)== FALSE)
		RETURN_FALSE( m_token, backup_x );
}


/*------------------------------------------------------------------------------------------
1. ��� :	where�� ó���ϴ� �Լ�.
��)  
------------------------------------------------------------------------------------------*/
int  where_Parser( Token_Pos *m_token,  CArrayEx *keyword_list,  
						Pattern_Type *m_start_pattern/* where */, Pattern_Type *m_end_pattern,/* ; */
						CATR *m_CATR , int atr_count , 
						QUERY_Datum *m_query_datum)
{	
	Token_Attr * current , *next, *next_next;
	Pattern_Type  m_start, m_end;
	int loop;
	CArrayEx * array = m_token->token_array;
	int *x			 = m_token->array_x;
	int backup_x = m_token->array_x[0];
	Token_Attr * pattern;
	Token_Attr nonterminal;
	
	int y=0;

	// [1]. compare start pattern("where  ")
	if( Find_Pattern( m_token, m_start_pattern)== FALSE)
		RETURN_FALSE( m_token, backup_x );
	
	
	// [2].
	while ( 1 ) 
	{
		// [2-1].  atr1 >= 35
		///////////////////////////////////////////////////////////////////////////////
		// 1. token : atr1
		if( (current = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
			return FALSE;
		
		if( (next = ( Token_Attr * ) array->ElementAt( x[0]++) ) == NULL)
			return FALSE;
		
		////////////////////////////////////////////////////////////////
		// attribute copy
		// memcpy( &m_query_datum->where[y].where_1st_attrib_name , current, sizeof(Token_Attr ) );
		
		///////////////////////////////////////////////////////////////
		// 2. ������ ī�� : >=
		if( next->type  == NONE )
		{
			RETURN_FALSE(m_token, backup_x);
		}
		// m_query_datum->where[y].OP = next->type;
		
		
		///////////////////////////////////////////////////////////////////////////////
		// 3. �񱳰�: 35
		if( (current = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
			RETURN_FALSE(m_token, backup_x);
		
		// 1) '���ڿ�'
		if(!strcmp(current->name, "'" ) )
		{
			
			// get token
			if( (next = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
				RETURN_FALSE(m_token, backup_x);
			
			if( (next_next = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
				RETURN_FALSE(m_token, backup_x);
			
			if( strcmp(next_next->name, "'" ) )
				RETURN_FALSE(m_token, backup_x);
			
			
			// �񱳰� ī��
			// memcpy( &m_query_datum->where[y].where_2nd_attrib_name, next, sizeof(Token_Attr) ); 
			// m_query_datum->condition_count = y+1;
			
		}
		
		// 2) ����
		else
		{
			// ���� token
			if ( current->type != DIGIT)
				RETURN_FALSE(m_token, backup_x);
			
			// ���� ī��.
			// memcpy( &m_query_datum->where[y].where_2nd_attrib_name, current, sizeof(Token_Attr) ); 
			// m_query_datum->condition_count = y+1;
			
		}
		
#if 0
		if( IsAttribute(m_CATR, atr_count, current) >= 0 )
			current->type = ATTRIBUTE_NAME;
		else
			return FALSE;
#endif
		
		// 
		if( Find_Pattern( m_token, m_end_pattern)== TRUE)
		{
			return TRUE;
		}
		else
		{
			if( (current = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
				RETURN_FALSE(m_token, backup_x);
		
			switch(current->type)
			{
				case AND :
				case OR :
				{
					//m_query_datum->where[y].rel_OP  =current->type;
					y++;
					
				}break;
				
				
				default:
					RETURN_FALSE(m_token, backup_x);
			}
			
			continue;
		}


		y++;
	}
	


	RETURN_FALSE(m_token, backup_x);

}

// end_pattern�� �տ� str�� ����ְ� �ڷ�� ���� ��Ų��
void addpattern (Pattern_Type *end_pattern, char *str)
{
	int x;

	for( x = end_pattern->count -1; x >= 0 ; x--)
	{
		memcpy( &end_pattern->pattern[x+1],  &end_pattern->pattern[x] , sizeof( Pattern_Type ) );
	
	}

	strcpy(end_pattern->pattern[0].name, str );

	end_pattern->count++;

}

int Select_Main_Parser( CArrayEx *lex_token_array, int *array_x,
					   CArrayEx *all_keyword, CArrayEx *aggregate_keyword,
					   Pattern_Type *end_pattern,
					   CATR *m_CATR , int atr_count , 
					   QUERY_Report *m_query_report)
{
	Pattern_Type m_start_pattern, m_end_pattern;
	int x;
	Token_Pos  m_token;
	int res;

	// 1. " select ~ from" parser
	m_token.token_array  = lex_token_array;
	m_token.array_x		 = array_x;
	m_token.retry_x		 = 0;

	m_start_pattern.count = 1;
	strcpy( m_start_pattern.pattern[0].name, "select" );
	
	m_end_pattern.count = 1;
	strcpy( m_end_pattern.pattern[0].name, "from" );

	res = Select_from_Parser(	&m_token		,	all_keyword,	aggregate_keyword,
								&m_start_pattern,	&m_end_pattern,
								m_CATR ,			atr_count , 
								&m_query_report->query[0]);
	if (res == FALSE)
		return FALSE;


	// 2. "from ~ where" parser
	m_token.array_x[0]--;
	m_start_pattern.count = 1;
	strcpy( m_start_pattern.pattern[0].name, "from" );
	
	m_end_pattern.count = 1;
	strcpy( m_end_pattern.pattern[0].name, "where" );

	res = from_where_Parser(	&m_token,			all_keyword, aggregate_keyword,
								&m_start_pattern,	&m_end_pattern,
								m_CATR ,			atr_count , 
								&m_query_report->query[0]); 

	if (res == FALSE)
		return FALSE;


	// 3. "where ~ " parser
	m_token.array_x[0]--;
	m_start_pattern.count = 1;
	strcpy( m_start_pattern.pattern[0].name, "where" );
	

	// 1) 
	if ( res = where_Parser(	&m_token,			all_keyword, 
								&m_start_pattern,	end_pattern,
								m_CATR ,			atr_count , 
								&m_query_report->query[0]) )
		return TRUE;
	
	// 2)
	addpattern(end_pattern, ")");
	if ( res = Where_IN_process_attribute_value(&m_token, all_keyword, aggregate_keyword,
												&m_start_pattern, end_pattern, m_CATR, atr_count, m_query_report ) )
		return TRUE;

	return res;
}

int Select_Main_Parser( CArrayEx *lex_token_array, int *array_x,
					   CArrayEx *all_keyword, CArrayEx *aggregate_keyword,
					   CATR *m_CATR , int atr_count , 
					   QUERY_Report *m_query_report)
{
	int res;
	Pattern_Type m_end_pattern;

	
	m_end_pattern.count = 1;
	strcpy( m_end_pattern.pattern[0].name, ";" );
	res = Select_Main_Parser(lex_token_array, array_x, 
							 all_keyword, aggregate_keyword,  
							 &m_end_pattern,
							 m_CATR, atr_count, m_query_report);
	return res;
}

QUERY_Report report;
void select_main(CArrayEx * lex_token_array)
{
	int x = 0, res;
	CATR atr;
	memset(&report, 0x0, sizeof(QUERY_Report) );
	res = Select_Main_Parser(lex_token_array, &x, &m_all_keyword_array, &m_aggregate_array,  &atr, 1, &report);
	
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
int Select_where_Parser( CArrayEx *token_array, int *array_x, CArrayEx *keyword_list,  CATR *m_CATR , int atr_count , QUERY_Datum *m_query_datum);
int Select_Parser( CArrayEx *token_array, int *array_x, CArrayEx *keyword_list,  CATR *m_CATR , int atr_count , QUERY_Datum *m_query_datum);




/*---------------------------------------------------------------------
1. ��	  �� : �Է¹��� �ļ�����Ÿ�� Insert_case1�� �´��� Ȯ���ϰ� 
				TABLE_NAME, ATTRIBUTE_NAME �Ӽ��� üũ�Ѵ�.
2. Parameter :
CDBI *m_pDBI
3. return	 : 
---------------------------------------------------------------------*/
#if 0
// insert into table values ( attribute_list ) ;
int IsAttribute(CATR *m_CATR, int atr_count, Token_Attr *current)
{
	int loop ;

	for(loop = 0; loop < atr_count; loop++)
	{
		if( !strcmp(m_CATR[loop].GetName(), current->name ) )
		{
			current->type = ATTRIBUTE_NAME;
			return loop;
		}
		
	
	}
	return -1;
}
#endif

/*
1. ��� :	select�� from������ attributeó�� �ϴ� �Լ�.
��)  select  [ atr1,  atr2 ] from
*/
int select_process_attribute( CArrayEx *array, int * x, char * end_string, CATR *m_CATR , int atr_count , QUERY_Datum *m_query_datum )
{
	Token_Attr * current , *next;
	
	int y = 0;
	while ( 1 ) 
	{
		
		// 2-1. attribute
		if( (current = ( Token_Attr * ) array->ElementAt( (*x)++ ) ) == NULL)
			return FALSE;
		
		
		// attribute
		memcpy( &m_query_datum->attrib_name[y++], current, sizeof(Token_Attr) ); 
		m_query_datum->count = y;
		
#if 0
		if( IsAttribute(m_CATR, atr_count, current) >= 0 )
			current->type = ATTRIBUTE_NAME;
		else
			return FALSE;
#endif
		
		// 3. from
		if( (next = ( Token_Attr * ) array->ElementAt( (*x)++ ) ) == NULL)
			return FALSE;
		// if(!strcmp(next->name, "from" ) )
		if(!strcmp(next->name, end_string) )
		{
			break;
		}
		// 2-2. attribute list
		else if ( next->type != COMMA )
			return FALSE;
	}
	
	return TRUE;
}

/*
1. ��� :	where������ ���ǹ� ó�� 
��)  where  [ ( attr1 >= 20 and attr2 <= 30 ) ] ;    where   [ attr1 >= 20 and attr2 <= 30 ; ]
*/
int where1_process_attribute_value( CArrayEx *array, int * x, 
								   CArrayEx *keyword_list, char * end_string, 
								   CATR *m_CATR , int atr_count , 
								   QUERY_Datum *m_query_datum )
{
	Token_Attr * current , *next, *next_next;
	
	int y = 0;
	
	
	while ( 1 ) 
	{
		///////////////////////////////////////////////////////////////////////////////
		// 6. token
		if( (current = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
			return FALSE;
		
		if( (next = ( Token_Attr * ) array->ElementAt( x[0]++) ) == NULL)
			return FALSE;
		
		memcpy( &m_query_datum->where[y].where_1st_attrib_name , current, sizeof(Token_Attr ) );
		
		if( next->type  == NONE )
		{
			return  FALSE;
		}
		m_query_datum->where[y].OP = next->type;
		
		
		///////////////////////////////////////////////////////////////////////////////
		// state comparison
		if( (current = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
			return FALSE;
		
		// 1) '���ڿ�'
		if(!strcmp(current->name, "'" ) )
		{
			
			// get token
			if( (next = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
				return FALSE;
			
			if( (next_next = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
				return FALSE;
			
			if( strcmp(next_next->name, "'" ) )
				return FALSE;
			
			
			// query
			memcpy( &m_query_datum->where[y].where_2nd_attrib_name, next, sizeof(Token_Attr) ); 
			m_query_datum->condition_count = y+1;
			
		}
		
		// 2) ����
		else
		{
			// ���� token
			if ( current->type != DIGIT)
				return FALSE;
			
			memcpy( &m_query_datum->where[y].where_2nd_attrib_name, current, sizeof(Token_Attr) ); 
			m_query_datum->condition_count = y+1;
			
		}
		
#if 0
		if( IsAttribute(m_CATR, atr_count, current) >= 0 )
			current->type = ATTRIBUTE_NAME;
		else
			return FALSE;
#endif
		
		// 7. token )
		if( (current = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
			return FALSE;
#if  1
		if(!strcmp(current->name, end_string ) )
		{
			return TRUE;
		}
		else
		{
		
			switch(current->type)
			{
				case AND :
				case OR :
				{
					m_query_datum->where[y].rel_OP  =current->type;
					y++;
					
				}break;
				
				
				default:
					return FALSE;
			}
			
			continue;
		}
#else
		if(!strcmp(current->name, end_string ) )
		{
			break;
		}
		// 6. attribute list  ,
		else if ( !strcmp(current->name, "and" ) )
		{
			if( (m_query_datum->where[y].rel_OP  =current->type ) == NONE )
			{
				return  FALSE;
			}
			y++;
			continue;
		}
		else if ( strcmp(current->name, "or" ) )
		{
			if( (m_query_datum->where[y].rel_OP  = Compare_Keyword( keyword_list, current->name  ) ) == NONE )
			{
				return  FALSE;
			}
			y++;
			continue;
		}

#endif

		y++;
	}
	
	return FALSE;
}

int where_in_process_attribute_value( CArrayEx *array, int * x, 
								   CArrayEx *keyword_list, char * end_string, 
								   CATR *m_CATR , int atr_count , 
								   QUERY_Datum *m_query_datum )
{
	Token_Attr * current , *next;
	
	int y = 0;
	int backup_x;
	
	
	while ( 1 ) 
	{
		///////////////////////////////////////////////////////////////////////////////
		// 6. token attribute & in etc( not in, exist, not exist ..., )
		if( (current = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
			return FALSE;
		
		if( (next = ( Token_Attr * ) array->ElementAt( x[0]++) ) == NULL)
			return FALSE;


		
		memcpy( &m_query_datum->where[y].where_1st_attrib_name , current, sizeof(Token_Attr ) );
		m_query_datum->where[y].OP = next->type;
		
		switch( next->type   )
		{
			case IN :
			case NOT_IN :
			{
				// starts "(" and ends ")"
				backup_x = x[0];
				if( (current = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
					return FALSE;
				if(current->type == L_PAREN ) // "("
				{
					
					
					// 7. ")"������ ���ǹ� ó��.
					if( Select_Parser( array, x, keyword_list,  m_CATR ,  atr_count , m_query_datum ) == TRUE)
					{
						
						if( (current = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
							return FALSE;
						if(strcmp(current->name, end_string ) )
						{
							return FALSE;
						}

						return TRUE;
						
					}
				}
				else
				{
					x[0] = backup_x;
					if ( Select_Parser( array, x, keyword_list,  m_CATR ,  atr_count , m_query_datum )  == TRUE)
					{
						
						if( (current = ( Token_Attr * ) array->ElementAt( x[0]++ ) ) == NULL)
							return FALSE;
						if(strcmp(current->name, end_string ) )
						{
							return FALSE;
						}
						
						return TRUE;
						
					}
				}
			
			}break;
			
			
			default :
			{
			}break;
			return  FALSE;
		}

		m_query_datum->where[y].OP = next->type;
	}
	return TRUE;
}


///////////////////////////////////////////////////////////////////////////////
/*
1. ��� : select���� where���� �Ľ��ϴ� �ڵ�.	
 */
int Select_where_Parser( CArrayEx *token_array, int *array_x, CArrayEx *keyword_list,  CATR *m_CATR , int atr_count , QUERY_Datum *m_query_datum)
{
	Token_Attr * current ;
	int  y = 0;
	
	
	memset(m_query_datum, 0x0, sizeof(QUERY_Datum) );
	
	// minimum token
	
	
	// 1. select
	if( (current = ( Token_Attr * ) token_array->ElementAt( array_x[0]++ ) ) == NULL)
		return FALSE;
	
	if(current->type != SELECT && strcmp(current->name, "select") )
	{
		return FALSE;
	}
	
	/////////////////////////////////////////////////////////////////////////
	// select ������ *, Attribute_list�� ��쿡 ���� �б�
	// 2. attribute & 3. from
	select_process_attribute( token_array, array_x, "from", m_CATR , atr_count , m_query_datum );
	
	
	// 4. table name
	if( (current = ( Token_Attr * ) token_array->ElementAt( array_x[0]++ ) ) == NULL)
		return FALSE;
	
	// compare current->name with current->name
	strcpy( m_query_datum->db_name , current->name); // db name
	m_query_datum->m_pDBI = NULL; //  DBI
	m_query_datum->work   = SELECT;
	
	// set table_name
	current->type = TABLE_NAME;
	
	
	//////////////////////////////////////////////////////////////////////////
	// 5. where
	if( (current = ( Token_Attr * ) token_array->ElementAt( array_x[0]++ ) ) == NULL)
		return FALSE;
	if(current->type != WHERE)
	{
		return FALSE;
	}
	
	return TRUE;
}



int Select_Parser( CArrayEx *token_array,  int *array_x, CArrayEx *keyword_list,  CATR *m_CATR , int atr_count , QUERY_Datum *m_query_datum)
{
	Token_Attr * current ;
	int *x = array_x, y = 0, res;



	// 1. parse tokens from select to where
	res = Select_where_Parser(token_array, x, keyword_list, m_CATR, atr_count, m_query_datum);

	if(res == FALSE)
		return FALSE;
	
	/////////////////////////////////////////////////////////////////////////
	// Where ������ ��쿡 ���� �б�
	// 6. 
	int backup_x = *x;
	if( (current = ( Token_Attr * ) token_array->ElementAt( x[0]++ ) ) == NULL)
		return FALSE;
	if(current->type == L_PAREN ) // "("
	{

		backup_x = *x;
		// 7. ")"������ ���ǹ� ó��.
		if( where1_process_attribute_value( token_array, x, keyword_list, ")", m_CATR ,  atr_count , m_query_datum ) == TRUE)
		{
			
			if( (current = ( Token_Attr * ) token_array->ElementAt( x[0]++ ) ) == NULL)
				return FALSE;
			
			if(!strcmp(current->name, ")" ) )
			{
				if( (current = ( Token_Attr * ) token_array->ElementAt( x[0]++ ) ) == NULL)
					return FALSE;

				if(!strcmp(current->name, ";" ) )
				{
					return TRUE;
				}
				return FALSE;
			}

			if(!strcmp(current->name, ";" ) )
			{
				return TRUE;
			}
			return FALSE;
		
		}
		
		*x = backup_x;
		if( where1_process_attribute_value( token_array, x, keyword_list, ")", m_CATR ,  atr_count , m_query_datum ) == TRUE)
		{
			
			if( (current = ( Token_Attr * ) token_array->ElementAt( x[0]++ ) ) == NULL)
				return FALSE;

			if(!strcmp(current->name, ")" ) )
			{
				if( (current = ( Token_Attr * ) token_array->ElementAt( x[0]++ ) ) == NULL)
					return FALSE;
				if(!strcmp(current->name, ";" ) )
				{
					return TRUE;
				}
				return FALSE;
			}
			if(!strcmp(current->name, ";" ) )
			{
				return TRUE;
			}
			return FALSE;
			
		}

		*x = backup_x;
		if ( where_in_process_attribute_value( token_array, x, keyword_list, ")", m_CATR ,  atr_count , m_query_datum+1 ) == TRUE)
		{
			
			if( (current = ( Token_Attr * ) token_array->ElementAt( x[0] ) ) == NULL)
				return FALSE;
			if(!strcmp(current->name, ";" ) )
			{
				return TRUE;
			}
			return FALSE;
			
		}
	}
	else
	{
		*x = backup_x;
		if ( where1_process_attribute_value( token_array, x, keyword_list, ";", m_CATR ,  atr_count , m_query_datum ) == TRUE)
			return TRUE;

		*x = backup_x;
		if ( where1_process_attribute_value( token_array, x, keyword_list, ")", m_CATR ,  atr_count , m_query_datum ) == TRUE)
		{

			return TRUE;

		}
		*x = backup_x;
		if ( where_in_process_attribute_value( token_array, x, keyword_list, ")", m_CATR ,  atr_count , m_query_datum+1 ) == TRUE)
		{
			
			if( (current = ( Token_Attr * ) token_array->ElementAt( x[0] ) ) == NULL)
				return FALSE;
			if(strcmp(current->name, ";" ) )
			{
				return FALSE;
			}
			return TRUE;
			
		}
	}


	return FALSE;

}

int Select_Main_Parser( CArrayEx *token_array,  
					   CArrayEx *all_keyword, CArrayEx *aggregate_keyword, 
					   CATR *m_CATR , int atr_count , 
					   QUERY_Report *m_query_report)
{
	int x = 0;
	QUERY_Datum *m_query_datum = &m_query_report->query[m_query_report->count++];
	return Select_Parser( token_array, &x, all_keyword,  m_CATR , atr_count , m_query_datum);
}





/////////////////////////////////////////////////////////////////////////////////////////////////



#if 0
#define MAX_TOKEN1  25
Token_Attr select_token[MAX_TOKEN1]= 
{
	{  "select"			, STRING },
	{  "attrib1"		, STRING },
	{  ","				, STRING },
	{  "attrib2"		, STRING },
	{  "from"			, STRING },
	{  "items"			, STRING },
	{  "where"			, STRING },
	{  "("				, STRING },
	{  "attrib3"		, STRING },
	{  ">="				, STRING },
	{  "123"			, DIGIT  },
	{  "and"			, STRING },
	{  "attrib1"		, STRING },
	{  "<="				, STRING },
	{  "'"				, STRING },
	{  "thomas"			, STRING },
	{  "'"				, STRING },
	{  "and"			, STRING },
	{  "attrib5"		, STRING },
	{  "<="				, STRING },
	{  "'"				, STRING },
	{  "hellen"			, STRING },
	{  "'"				, STRING },
	{  ")"				, STRING },
//	{  "not"			, STRING },
//	{  "in"				, STRING },
	{  ";"				, STRING }
	
};
#else
#define MAX_TOKEN1  32
// select attrib1, attrib2  from items where (attrib3 in 
//	(select atr3, atr4 from custom where atr1 <= 123 and atr2 <= 'hellen');
Token_Attr select_token[MAX_TOKEN1]= 
{		
	{  "select"			, STRING },
	{  "attrib1"		, STRING },
	{  ","				, STRING },
	{  "attrib2"		, STRING },
	{  "from"			, STRING },
	{  "items"			, STRING },
	{  "where"			, STRING },
	{  "("				, STRING },
	{  "attrib3"		, STRING },
	{  "in"				, STRING },
	{  "("				, STRING },
	{  "select"			, STRING },
	{  "atr3"			, STRING },
	{  ","				, STRING  },
	{  "atr4"			, STRING },
	{  "from"			, STRING },
	{  "custom"			, STRING },
	{  "where"			, STRING},
	{  "("				, STRING },
	{  "atr1"			, STRING },
	{  "<="				, STRING },
	{  "123"			, DIGIT },
	{  "and"			, STRING },
	{  "atr2"			, STRING },
	{  "<="				, STRING },
	{  "'"				, STRING },
	{  "hellen"			, STRING },
	{  "'"				, STRING },
	{  ")"				, STRING },
	{  ")"				, STRING },
	{  ")"				, STRING },
	{  ";"				, STRING }
	
};
#endif


#endif
////////////////////////////////////////////////////
// Items table
typedef struct  
{
	int  code;
	char name[100];
	int  price;
} Items;
#if 0
QUERY_Report report;
void select_1_main()
{

	CArrayEx a;
	CATR  atr;

	int x;


	// [1]. Keyword ���
	Init_Keyword( &m_all_keyword_array,		m_all_keyword,			MAX_KEYWORD);
	Init_Keyword( &m_aggregate_array,		m_aggregate_keyword,	MAX_AGGREATION);
	Init_Keyword( &m_relative_array,		m_relative_keyword,		MAX_RELATION);
	Init_Keyword( &m_conjunction_array,		m_conjunction_keyword,	MAX_CONJUNCTION);
	Init_Keyword( &m_in_array,				m_in_keyword,			MAX_IN);

	

	// [2]. Insert a Token into CArrayEx a
	a.Init( MAX_TOKEN1, sizeof( Token_Attr ));

	a.InsertHead(&select_token[0], MAX_TOKEN1);


	////////////////////////////////////////////
	// [3].  Lexical �м�
	Not_Lexical( &a, &m_all_keyword_array );
	for( x = 0 ; x < a.GetCurrent() ; x++ )
	{
		Token_Attr * p = ( Token_Attr * )a.ElementAt(x);
		if( strlen(p->name) )
			printf("%s ",  p->name);
			// printf("[%d] %s %d \n", x, p->name, p->type);
	}

	////////////////////////////////////////////
#if 0

	// Start_Nonterm_End_Parser(  , keyword_array,  ,)
	
#else
	memset(&report, 0x0, sizeof(QUERY_Report) );
	x = Select_Main_Parser(&a, &m_all_keyword_array, &m_aggregate_array,  &atr, 1, &report);
#endif	


	
}
#endif

